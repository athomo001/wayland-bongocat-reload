{
  lib,
  config,
  pkgs,
  ...
}:
let
  cfg = config.programs.wayvpet;
  wayvpet = pkgs.callPackage ./default.nix { };
  configFile = pkgs.writeTextFile {
    name = "wayvpet.conf";
    text = ''
      # Auto-generated config for `wayvpet`

      # Cat position and size
      cat_x_offset=${toString cfg.catXOffset}
      cat_y_offset=${toString cfg.catYOffset}
      cat_height=${toString cfg.catHeight}
      cat_align=${cfg.catAlign}

      # Visual settings
      mirror_x=${if cfg.mirrorX then "1" else "0"}
      mirror_y=${if cfg.mirrorY then "1" else "0"}
      enable_antialiasing=${if cfg.enableAntialiasing then "1" else "0"}

      # Overlay settings
      overlay_position=${cfg.overlayPosition}
      overlay_height=${toString cfg.overlayHeight}
      overlay_opacity=${toString cfg.overlayOpacity}
      layer=${cfg.layer}

      # Animation settings
      idle_frame=${toString cfg.idleFrame}
      keypress_duration=${toString cfg.keypressDuration}
      test_animation_duration=${toString cfg.testAnimationDuration}
      test_animation_interval=${toString cfg.testAnimationInterval}
      fps=${toString cfg.fps}
      enable_hand_mapping=${if cfg.enableHandMapping then "1" else "0"}

      # Sleep mode
      idle_sleep_timeout=${toString cfg.idleSleepTimeout}
      enable_scheduled_sleep=${if cfg.enableScheduledSleep then "1" else "0"}
      sleep_begin=${cfg.sleepBegin}
      sleep_end=${cfg.sleepEnd}

      # Debug mode
      enable_debug=${if cfg.enableDebug then "1" else "0"}

      # Monitor
      monitor=${cfg.monitor}

      # Input devices
      ${lib.concatMapStringsSep "\n" (device: "keyboard_device=${device}") cfg.inputDevices}
      ${lib.concatMapStringsSep "\n" (name: "keyboard_name=${name}") cfg.inputDeviceNames}
      hotplug_scan_interval=${toString cfg.hotplugScanInterval}
    ''
    + lib.optionalString (cfg.extraConfig != "") ("\n# Extra Config\n" + cfg.extraConfig);
  };
in
{
  meta.maintainers = with lib.maintainers; [ ];
  options.programs.wayvpet = {
    enable = lib.mkOption {
      type = lib.types.bool;
      default = false;
      example = true;
      description = "Enable `wayvpet` overlay";
    };
    autostart = lib.mkOption {
      type = lib.types.bool;
      default = false;
      example = true;
      description = "Enable and automatically start `wayvpet-wayland` as a service on login";
    };

    package = lib.mkOption {
      type = lib.types.package;
      default = wayvpet;
      description = "The wayvpet package to use.";
    };

    # Debug mode
    enableDebug = lib.mkOption {
      type = lib.types.bool;
      default = false;
      example = true;
      description = "Enable debug logging";
    };

    # Overlay
    overlayPosition = lib.mkOption {
      type = lib.types.enum [ "top" "bottom" ];
      default = "top";
      example = "bottom";
      description = "Wayvpet overlay position on screen - `top` or `bottom`";
    };
    overlayHeight = lib.mkOption {
      type = lib.types.ints.between 20 300;
      default = 60;
      example = 70;
      description = "Height of the entire overlay bar";
    };
    overlayOpacity = lib.mkOption {
      type = lib.types.ints.between 0 255;
      default = 0;
      example = 20;
      description = "Overlay background opacity (0-255, 0 = transparent)";
    };

    # Position
    catXOffset = lib.mkOption {
      type = lib.types.int;
      default = 120;
      example = 200;
      description = "Horizontal offset from center position (pixels)";
    };
    catYOffset = lib.mkOption {
      type = lib.types.int;
      default = 0;
      example = 10;
      description = "Vertical offset from center position (pixels)";
    };

    # Size
    catHeight = lib.mkOption {
      type = lib.types.ints.between 10 200;
      default = 80;
      example = 50;
      description = "Height of the bongo cat in pixels";
    };
    catAlign = lib.mkOption {
      type = lib.types.enum [ "left" "center" "right" ];
      default = "center";
      example = "right";
      description = "Horizontal alignment: left, center, or right";
    };

    # Visual settings
    mirrorX = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = "Flip cat horizontally";
    };
    mirrorY = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = "Flip cat vertically";
    };
    enableAntialiasing = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Enable smooth scaling (recommended)";
    };
    layer = lib.mkOption {
      type = lib.types.enum [ "background" "bottom" "top" "overlay" ];
      default = "top";
      example = "overlay";
      description = "Layer type: background, bottom, top, or overlay";
    };

    # Sleep mode
    idleSleepTimeout = lib.mkOption {
      type = lib.types.ints.between 0 3600;
      default = 0;
      example = 300;
      description = "Seconds of inactivity before sleep (0 = disabled)";
    };
    enableScheduledSleep = lib.mkOption {
      type = lib.types.bool;
      default = false;
      description = "Enable scheduled sleep mode";
    };
    sleepBegin = lib.mkOption {
      type = lib.types.str;
      default = "22:00";
      description = "Sleep schedule start time (HH:MM)";
    };
    sleepEnd = lib.mkOption {
      type = lib.types.str;
      default = "06:00";
      description = "Sleep schedule end time (HH:MM)";
    };

    # Animations
    idleFrame = lib.mkOption {
      type = lib.types.ints.between 0 4;
      default = 0;
      example = 1;
      description = "Frame to use when idle (0, 1, or 2)";
    };
    keypressDuration = lib.mkOption {
      type = lib.types.ints.between 10 5000;
      default = 150;
      example = 100;
      description = "Animation duration after keypress (ms)";
    };
    testAnimationDuration = lib.mkOption {
      type = lib.types.ints.between 10 5000;
      default = 200;
      example = 100;
      description = "Test animation duration (ms)";
    };
    testAnimationInterval = lib.mkOption {
      type = lib.types.ints.between 0 3600;
      default = 0;
      example = 10;
      description = "How often to trigger test animation (seconds, 0 = disabled)";
    };

    # Performance
    fps = lib.mkOption {
      type = lib.types.ints.between 1 120;
      default = 60;
      example = 120;
      description = "Animation framerate (FPS)";
    };
    enableHandMapping = lib.mkOption {
      type = lib.types.bool;
      default = true;
      description = "Map left/right keyboard halves to left/right cat hands";
    };

    # Input devices
    inputDevices = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [ "/dev/input/event4" ];
      description = "List of input devices to monitor, run `wayvpet-find-devices` to see all devices to add to this list";
      example = [
        "/dev/input/event4"
        "/dev/input/event20"
      ];
    };

    inputDeviceNames = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      default = [ ];
      description = "List of input device names to monitor, run `wayvpet-find-devices` to see all devices to add to this list";
      example = [
        "hfd.cn KW75 Keyboard"
      ];
    };

    hotplugScanInterval = lib.mkOption {
      type = lib.types.ints.between 0 3600;
      default = 30;
      description = "Seconds between input rescans (0 scans once)";
    };

    monitor = lib.mkOption {
      type = lib.types.str;
      default = "";
      description = "The monitor for the Cat";
      example = "eDP-1";
    };

    # Extra Config
    extraConfig = lib.mkOption {
      type = lib.types.str;
      default = "";
      description = "Extra lines to add to wayvpet.conf";
    };
  };

  # Internal configuration (not exposed to users)
  options._bongocat = lib.mkOption {
    type = lib.types.attrs;
    internal = true;
    visible = false;
    default = { };
  };

  config._bongocat = lib.mkIf cfg.enable {
    inherit cfg configFile;
  };
}
