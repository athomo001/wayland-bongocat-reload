{pkgs ? import <nixpkgs> {}}:
pkgs.mkShellNoCC {
  nativeBuildInputs = with pkgs; [
    # Build dependencies
    cargo
    rustc
    pkg-config # Finds build dependencies
    gcc # Native compiler for dependencies

    # Wayland
    wayland-scanner

    # Devtools
    gdb # Debugger
    valgrind # Memory debugger
    clang-tools # Useful tools for C/C++ including a formatter `clang-format`

    # Optional tools for input device debugging
    evtest
    udev
  ];
  buildInputs = with pkgs; [
    wayland
    wayland-protocols
  ];
  shellHook = ''
    # Simple TUI
    echo "🐱 wayvpet Development Environment"
    echo "Build output is stored in 'build' if you don't use 'nix build'"
    echo "Commands:"
    echo "  nix build         - Build the Nix package (Build output is stored in 'result')"
    echo "  make              - Build the project"
    echo "  make debug        - Build with debug symbols"
    echo "  make release      - Build in release mode with optimizations and such (Longer compile time)"
    echo "  make protocols    - Generate protocol files"
    echo "  make embed-assets - Generate embedded assets"
    echo "  make clean        - Clean build artifacts"
    echo "  make memcheck     - Run with valgrind (Requires debug build)"
    echo ""
    echo "Helper scripts:"
    echo "  ./scripts/find_input_devices.sh - Find input devices"
    echo "  ./scripts/test_nix_build.sh     - Test Nix flake and package"
    echo "  ./scripts/test_toggle.sh        - Test Wayvpet toggle functionality (Install Wayvpet first)"
  '';
}
