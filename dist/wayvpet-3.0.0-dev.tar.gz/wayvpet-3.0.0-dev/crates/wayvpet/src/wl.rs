//! Wayland: el overlay (rebanadas 1–6 de la Fase 0.5).
//!
//! Layer-surface con `smithay-client-toolkit`, bucle `calloop`, región de
//! entrada vacía (click-through), rasterizado del gato, lector de teclado,
//! máquina de estados, fondo con `overlay_opacity`, espejo, y `--watch-config`
//! (recarga en caliente).
//!
//! Auto-ocultar en pantalla completa vía `zwlr_foreign_toplevel_management_v1`
//! (wlroots, KWin) o `zcosmic_toplevel_info_v1` (COSMIC) — ver `cosmic.rs`.
//! HiDPI con `wp_viewporter` + `wp_fractional_scale_v1` (búfer físico → capa
//! lógica). `--monitor` fija la salida. Socket de control IPC (spec 0003 M1:
//! PING/STATE/QUIT). Porta `src/platform/wayland.c`.

use std::error::Error;
use std::time::{Duration, Instant};

use calloop::signals::{Signal, Signals};
use calloop::timer::{TimeoutAction, Timer};
use calloop::EventLoop;
use calloop_wayland_source::WaylandSource;
use smithay_client_toolkit::{
    compositor::{CompositorHandler, CompositorState},
    delegate_compositor, delegate_layer, delegate_output, delegate_pointer, delegate_registry,
    delegate_seat, delegate_shm,
    output::{OutputHandler, OutputState},
    registry::{ProvidesRegistryState, RegistryState},
    registry_handlers,
    seat::{
        pointer::{PointerEvent, PointerEventKind, PointerHandler},
        Capability, SeatHandler, SeatState,
    },
    shell::{
        wlr_layer::{
            Anchor, KeyboardInteractivity, Layer, LayerShell, LayerShellHandler, LayerSurface,
            LayerSurfaceConfigure,
        },
        WaylandSurface,
    },
    shm::{slot::SlotPool, Shm, ShmHandler},
};
use wayland_client::{
    delegate_noop, event_created_child,
    globals::registry_queue_init,
    protocol::{wl_compositor, wl_output, wl_pointer, wl_region, wl_seat, wl_shm, wl_surface},
    Connection, Dispatch, Proxy, QueueHandle,
};
use wayland_protocols_wlr::foreign_toplevel::v1::client::{
    zwlr_foreign_toplevel_handle_v1::{self as ftl_handle, ZwlrForeignToplevelHandleV1},
    zwlr_foreign_toplevel_manager_v1::{self as ftl_mgr, ZwlrForeignToplevelManagerV1},
};
use wayvpet_common::config::{Align, Config};
use wayvpet_common::paw::{self, apply_mirror, frame_from_paw_state, FRAME_SLEEPING};

use std::collections::HashMap;
use std::io::Write;
use std::path::PathBuf;
use std::thread;

use wayland_protocols::ext::foreign_toplevel_list::v1::client::{
    ext_foreign_toplevel_handle_v1::{self as ext_handle, ExtForeignToplevelHandleV1},
    ext_foreign_toplevel_list_v1::{self as ext_list, ExtForeignToplevelListV1},
};
use wayland_protocols::wp::fractional_scale::v1::client::{
    wp_fractional_scale_manager_v1::WpFractionalScaleManagerV1,
    wp_fractional_scale_v1::{self as fs_v1, WpFractionalScaleV1},
};
use wayland_protocols::wp::viewporter::client::{
    wp_viewport::WpViewport, wp_viewporter::WpViewporter,
};

use wayvpet_common::scale::{scale_offset_120, scale_size_120, unscale_offset_120};

use crate::anim::{self, Frames};
use crate::cosmic::{
    zcosmic_toplevel_handle_v1::{self as cosmic_handle, ZcosmicToplevelHandleV1},
    zcosmic_toplevel_info_v1::{self as cosmic_info, ZcosmicToplevelInfoV1},
};
use crate::{input, input_child, ipc, theme, tray, watch};

/// Valores del enum `state` de `zwlr_foreign_toplevel_handle_v1` (y del enum
/// homónimo de `zcosmic_toplevel_handle_v1`: mismos números).
const TOPLEVEL_STATE_ACTIVATED: u32 = 2;
const TOPLEVEL_STATE_FULLSCREEN: u32 = 3;

/// Interpreta el array `state` de un toplevel (u32 en orden nativo) y devuelve
/// `(fullscreen, activated)`. Común a los protocolos wlr y COSMIC.
fn parse_toplevel_state(arr: &[u8]) -> (bool, bool) {
    let mut fullscreen = false;
    let mut activated = false;
    for chunk in arr.chunks_exact(4) {
        let v = u32::from_ne_bytes([chunk[0], chunk[1], chunk[2], chunk[3]]);
        activated |= v == TOPLEVEL_STATE_ACTIVATED;
        fullscreen |= v == TOPLEVEL_STATE_FULLSCREEN;
    }
    (fullscreen, activated)
}

/// Estado de un toplevel que nos interesa para ocultar el gato.
#[derive(Default)]
struct TopInfo {
    fullscreen: bool,
    activated: bool,
}

/// Botón izquierdo del ratón en el protocolo Linux `input-event-codes.h`.
const BTN_LEFT: u32 = 0x110;

/// Estado del modo edición con ratón (spec 0005). La geometría vive en
/// `wayvpet_common::edit`; aquí solo el estado del arrastre.
#[derive(Default)]
struct EditState {
    active: bool,
    dragging: bool,
    /// Desplazamiento puntero → origen del gato al agarrar (lógicas).
    grab_dx: f64,
    grab_dy: f64,
    /// Última posición conocida del puntero (para re-anclar al usar la rueda).
    ptr: (f64, f64),
    /// `(cat_x_offset, cat_y_offset, cat_height)` al entrar, para "¿cambió algo?".
    snapshot: (i32, i32, i32),
}

/// Sonda de salidas: cola de eventos aparte para resolver `--monitor NOMBRE`
/// antes de crear la layer-surface (SCTK reclama `wl_output` en la principal).
#[derive(Default)]
struct OutputProbe {
    outputs: Vec<(wl_output::WlOutput, Option<String>)>,
}

impl Dispatch<wl_output::WlOutput, ()> for OutputProbe {
    fn event(
        state: &mut Self,
        proxy: &wl_output::WlOutput,
        event: wl_output::Event,
        _: &(),
        _conn: &Connection,
        _qh: &QueueHandle<Self>,
    ) {
        if let wl_output::Event::Name { name } = event {
            if let Some(slot) = state.outputs.iter_mut().find(|(o, _)| o == proxy) {
                slot.1 = Some(name);
            }
        }
    }
}

/// Rasteriza los 5 fotogramas a la altura `h` (px) desde el tema cargado, o del
/// embebido si no hay. Un tema SVG (`theme_format` 1/2) va por `rasterize_from`;
/// uno de sprite sheet (formato 3, spec 0014) por `rasterize_sheet`.
fn rasterize_loaded(
    theme: Option<&theme::LoadedTheme>,
    h: u32,
    mx: bool,
    my: bool,
) -> Result<Frames, Box<dyn Error>> {
    let Some(t) = theme else {
        return anim::rasterize(h, mx, my);
    };
    match &t.art {
        theme::ThemeArt::Svg(svgs) => {
            anim::rasterize_from(svgs.as_ref(), t.meta.aspect, false, h, mx, my)
        }
        theme::ThemeArt::Sheet(s) => anim::rasterize_sheet(&s.sheet, &s.images, h, mx, my),
    }
}

/// Rasteriza los 5 fotogramas: del tema si hay, si no del embebido.
fn rasterize_theme(
    theme: Option<&theme::LoadedTheme>,
    cfg: &Config,
) -> Result<Frames, Box<dyn Error>> {
    rasterize_loaded(
        theme,
        cfg.cat_height.max(1) as u32,
        cfg.mirror_x,
        cfg.mirror_y,
    )
}

/// Tope de sondeo cuando no hay nada pendiente (sin patas sueltas, sin
/// antirrebote de pantalla completa en curso, sin sprite sheet animando): red
/// de seguridad para el sueño programado/por inactividad, `boring` y el
/// decaimiento de `happy_kpm`, cuya granularidad de segundos no necesita más
/// precisión. Ver [`State::next_wake`] — cierra el TODO de `## Notas` en
/// `specs/PRESUPUESTOS.md` (el timer tickeaba siempre a `fps`, ~60 Hz, aunque
/// nada cambiara).
const IDLE_TICK_CAP: Duration = Duration::from_millis(200);

/// Próximo instante en que hace falta volver a llamar a `tick()` para no
/// perder un cambio: el primero de `candidates` que caiga en el futuro
/// (patas sueltas, fin del antirrebote de pantalla completa, siguiente
/// fotograma de un sprite sheet en curso); si ninguno aplica, `now + idle_cap`.
/// Nunca acorta un candidato real más lejano que `idle_cap` — solo rellena
/// cuando no hay nada concreto que esperar.
#[must_use]
fn next_wake_at(now: Instant, candidates: &[Option<Instant>], idle_cap: Duration) -> Instant {
    candidates
        .iter()
        .filter_map(|c| *c)
        .filter(|&t| t > now)
        .min()
        .unwrap_or(now + idle_cap)
}

/// Hora local en minutos desde medianoche (`0..1440`), o `None` si falla.
/// Equivale a `time()` + `localtime_r()` de `anim_is_sleep_time` (respeta `$TZ`
/// y `/etc/localtime`). La lógica de la franja vive en `wayvpet_common::sleep`.
#[allow(unsafe_code)] // FFI puntual y documentado: time + localtime_r
fn local_now_minutes() -> Option<i32> {
    // SAFETY: `time(NULL)` devuelve el epoch actual; `localtime_r` escribe en un
    // `tm` de pila propio y devuelve ese mismo puntero (o NULL en error).
    unsafe {
        let t = libc::time(std::ptr::null_mut());
        let mut tm: libc::tm = std::mem::zeroed();
        if libc::localtime_r(&t, &mut tm).is_null() {
            return None;
        }
        Some(tm.tm_hour * 60 + tm.tm_min)
    }
}

/// Arranca el overlay: conecta a Wayland, crea la layer-surface y corre el bucle
/// `calloop`. Con `watch_config`, vigila `config_path` y recarga en caliente.
/// Devuelve cuando el compositor cierra la surface o llega SIGINT/SIGTERM.
pub fn run_overlay(
    config: &Config,
    config_path: Option<PathBuf>,
    watch_config: bool,
    no_toplevel: bool,
    tray_enabled: bool,
    input: input::Isolated,
    target_output_name: Option<String>,
) -> Result<(), Box<dyn Error>> {
    let conn = Connection::connect_to_env()?;
    let (globals, event_queue) = registry_queue_init(&conn)?;
    let qh: QueueHandle<State> = event_queue.handle();

    let compositor =
        CompositorState::bind(&globals, &qh).map_err(|e| format!("falta wl_compositor: {e}"))?;
    let layer_shell = LayerShell::bind(&globals, &qh)
        .map_err(|e| format!("el compositor no soporta wlr-layer-shell: {e}"))?;
    let shm = Shm::bind(&globals, &qh).map_err(|e| format!("falta wl_shm: {e}"))?;

    // HiDPI (opcional): `wp_viewporter` + `wp_fractional_scale_v1`. Con ambos, el
    // búfer se rasteriza a píxeles físicos y `wp_viewport` lo mapea al tamaño
    // lógico de la capa. Sin `viewporter` no se escala (búfer = tamaño lógico).
    let viewporter = globals.bind::<WpViewporter, _, _>(&qh, 1..=1, ()).ok();
    let fs_mgr = globals
        .bind::<WpFractionalScaleManagerV1, _, _>(&qh, 1..=1, ())
        .ok();
    match (viewporter.is_some(), fs_mgr.is_some()) {
        (true, true) => eprintln!("wayvpet: HiDPI: fractional-scale + viewporter"),
        (true, false) => eprintln!("wayvpet: HiDPI: viewporter (escala entera de la salida)"),
        _ => eprintln!("wayvpet: sin viewporter; sin escalado HiDPI"),
    }

    // Detección de pantalla completa (opcional). Se prueba primero el protocolo
    // wlr (sway, Hyprland, river, KWin); si no está, el camino COSMIC:
    // `ext-foreign-toplevel-list-v1` (la lista) + `zcosmic_toplevel_info_v1` v2
    // (el estado de cada uno). Si no hay ninguno, el gato no se auto-oculta.
    let ftl_mgr = if no_toplevel {
        None
    } else {
        globals
            .bind::<ZwlrForeignToplevelManagerV1, _, _>(&qh, 1..=3, ())
            .ok()
    };
    let (ext_list, cosmic_info) = if no_toplevel {
        eprintln!("wayvpet: --no-toplevel: sin detección de pantalla completa");
        (None, None)
    } else if ftl_mgr.is_none() {
        let list = globals
            .bind::<ExtForeignToplevelListV1, _, _>(&qh, 1..=1, ())
            .ok();
        let info = globals
            .bind::<ZcosmicToplevelInfoV1, _, _>(&qh, 2..=3, ())
            .ok();
        // Solo sirve si están los dos: la lista da los handles y el "info" el estado.
        if list.is_some() && info.is_some() {
            (list, info)
        } else {
            (None, None)
        }
    } else {
        (None, None)
    };
    match (ftl_mgr.is_some(), cosmic_info.is_some()) {
        (true, _) => eprintln!("wayvpet: auto-ocultar en pantalla completa: activo (wlr)"),
        (_, true) => eprintln!("wayvpet: auto-ocultar en pantalla completa: activo (cosmic)"),
        _ if !no_toplevel => {
            eprintln!("wayvpet: sin protocolo de toplevels; el gato no se auto-ocultará");
        }
        _ => {}
    }

    // Multi-monitor: si se pidió una salida por nombre, la resolvemos con una
    // cola de eventos aparte (SCTK reclama `wl_output` en la principal, no
    // podemos tener dos `Dispatch<WlOutput>` para el mismo estado).
    let target_output: Option<wl_output::WlOutput> = match &target_output_name {
        Some(name) => {
            let mut probe_q = conn.new_event_queue::<OutputProbe>();
            let probe_qh = probe_q.handle();
            let mut probe = OutputProbe::default();
            for g in globals.contents().clone_list() {
                if g.interface == "wl_output" {
                    let o = globals.registry().bind::<wl_output::WlOutput, _, _>(
                        g.name,
                        g.version.min(4),
                        &probe_qh,
                        (),
                    );
                    probe.outputs.push((o, None));
                }
            }
            // Dos roundtrips: el evento `name` puede llegar en el segundo.
            probe_q.roundtrip(&mut probe)?;
            probe_q.roundtrip(&mut probe)?;
            match probe
                .outputs
                .into_iter()
                .find(|(_, n)| n.as_deref() == Some(name.as_str()))
            {
                Some((o, _)) => {
                    eprintln!("wayvpet: overlay en la salida '{name}'");
                    Some(o)
                }
                None => {
                    eprintln!("wayvpet: salida '{name}' no encontrada; uso la de por defecto");
                    None
                }
            }
        }
        None => None,
    };

    // Tamaño de reserva hasta el primer `configure`: el compositor dimensiona la
    // superficie a la salida entera (anclada a los cuatro lados, tamaño 0×0).
    let height: u32 = config.overlay_height.max(1) as u32;
    let width: u32 = config.screen_width.max(1) as u32;

    let surface = compositor.create_surface(&qh);

    // Click-through: región de entrada VACÍA → los clics (y el ratón) pasan a
    // lo que haya debajo del overlay. Sin esto, la barra se traga todos los
    // clics de su rectángulo. Porta `wl_surface_set_input_region` de
    // `wayland_setup_surface`. Se aplica en el `layer.commit()` de abajo.
    let empty_region = compositor.wl_compositor().create_region(&qh, ());
    surface.set_input_region(Some(&empty_region));
    empty_region.destroy();

    let layer = layer_shell.create_layer_surface(
        &qh,
        surface,
        Layer::Top,
        Some("wayvpet"),
        target_output.as_ref(), // None = la salida que elija el compositor
    );

    // Superficie a **pantalla completa** y transparente: el vpet se dibuja en
    // cualquier `(x, y)` y el resto es click-through. Anclar a los cuatro lados
    // + tamaño 0×0 hace que el compositor la dimensione a la salida entera.
    // `overlay_height` / `overlay_position` / `overlay_opacity` quedan como
    // legado (ya no cambian la superficie; el vpet se posiciona con
    // `cat_y_offset` y se arrastra con el modo edición). `height`/`width` siguen
    // como tamaño de reserva hasta el primer `configure`.
    layer.set_anchor(Anchor::TOP | Anchor::BOTTOM | Anchor::LEFT | Anchor::RIGHT);
    layer.set_size(0, 0);
    layer.set_exclusive_zone(-1); // no reservar espacio; el overlay flota
    layer.set_keyboard_interactivity(KeyboardInteractivity::None);
    layer.commit();

    // Empareja la superficie con un viewport (para renderizar a resolución
    // física) y un receptor de fractional-scale (para saber la escala preferida).
    let viewport = viewporter
        .as_ref()
        .map(|vp| vp.get_viewport(layer.wl_surface(), &qh, ()));
    let fs_obj = fs_mgr
        .as_ref()
        .map(|m| m.get_fractional_scale(layer.wl_surface(), &qh, ()));

    let pool = SlotPool::new((width * height * 4) as usize, &shm)?;

    // Tema (spec 0006): si `theme=` está, se cargan sus 5 SVG; si falla, el
    // gato embebido (`classic`) sigue disponible siempre.
    let theme = theme::resolve(&config.theme);
    let frames = rasterize_theme(theme.as_ref(), config)?;
    eprintln!(
        "wayvpet: {} fotogramas rasterizados a {}x{} (aspecto {}:{})",
        5, frames.w, frames.h, frames.aspect.0, frames.aspect.1
    );

    let now = Instant::now();
    let mut state = State {
        registry_state: RegistryState::new(&globals),
        output_state: OutputState::new(&globals, &qh),
        seat_state: SeatState::new(&globals, &qh),
        wl_compositor: compositor.wl_compositor().clone(),
        _pointer: None,
        edit: EditState::default(),
        qh: qh.clone(),
        shm,
        pool,
        layer,
        config: config.clone(),
        config_path: config_path.clone(),
        frames,
        theme,
        frame: config.idle_frame.clamp(0, 4) as u8,
        left_hold_until: now,
        right_hold_until: now,
        last_activity: now,
        gaze_dir: wayvpet_common::mouse::GazeDirection::Center,
        last_gaze_at: now,
        roam_x: 0.0,
        roam_dir: 0.0,
        scratch_until: None,
        scratch_dir: 0.0,
        last_roam_tick: now,
        kpm: crate::kpm::Kpm::new(),
        last_reload: now,
        tray: None,
        last_tray_hidden: None,
        _ftl_mgr: ftl_mgr,
        _ext_list: ext_list,
        cosmic_info,
        toplevels: HashMap::new(),
        ext_to_cosmic: HashMap::new(),
        hidden: false,
        want_hidden: false,
        want_hidden_since: now,
        width,
        height,
        scale_120: 120,
        viewport,
        _fs_mgr: fs_mgr,
        _fs_obj: fs_obj,
        _target_output: target_output,
        ipc_dirty: std::collections::HashSet::new(),
        manual_hidden: None,
        exit: false,
        configured: false,
    };

    // ── Bucle de eventos ────────────────────────────────────────────────────
    let mut event_loop: EventLoop<State> = EventLoop::try_new()?;
    let lh = event_loop.handle();

    WaylandSource::new(conn, event_queue)
        .insert(lh.clone())
        .map_err(|e| format!("no se pudo insertar la fuente Wayland en calloop: {e}"))?;

    // Ctrl+C / kill → salir limpio.
    lh.insert_source(
        Signals::new(&[Signal::SIGINT, Signal::SIGTERM])?,
        |_, _, state| {
            eprintln!("wayvpet: señal recibida, saliendo");
            state.exit = true;
        },
    )?;

    // Lector de teclado: corre en el proceso hijo aislado. Un hilo puente lee su
    // tubería (bytes = bits de pata ya reducidos) y los mete en el canal calloop.
    let (tx, rx) = calloop::channel::channel::<u8>();
    {
        let pipe = std::fs::File::from(input.read);
        thread::Builder::new()
            .name("input:bridge".into())
            .spawn(move || input_child::parent_bridge(pipe, tx))
            .map_err(|e| format!("no se pudo crear el hilo puente de input: {e}"))?;
    }
    lh.insert_source(rx, |ev, _, state| {
        if let calloop::channel::Event::Msg(bit) = ev {
            state.on_paw(bit);
        }
    })?;

    // --watch-config: hilo con inotify → recarga en caliente (con debounce).
    if watch_config {
        if let Some(path) = config_path {
            let (wtx, wrx) = calloop::channel::channel::<()>();
            watch::spawn(path, wtx);
            lh.insert_source(wrx, |ev, _, state| {
                if let calloop::channel::Event::Msg(()) = ev {
                    state.reload();
                }
            })?;
        } else {
            eprintln!("wayvpet: --watch-config sin fichero de configuración; se ignora");
        }

        // Directorio del tema activo (spec 0006 M6): editar un SVG / PNG del
        // tema con `-w` lo recarga de disco en caliente. El watcher no sigue a
        // un cambio de tema en runtime; para eso, reiniciar.
        if let Some(dir) = state.theme.as_ref().map(|t| t.dir.clone()) {
            let (dtx, drx) = calloop::channel::channel::<()>();
            watch::spawn_dir(dir, dtx);
            lh.insert_source(drx, |ev, _, state| {
                if let calloop::channel::Event::Msg(()) = ev {
                    state.reload_theme();
                }
            })?;
        }
    }

    // Icono de bandeja (spec 0011): hilo `ksni` → cada clic de menú llega como un
    // `TrayCommand` que se ejecuta con la misma lógica que los verbos IPC. El
    // handle vive en `State` (para poder empujarle cambios de estado) y se
    // suelta al salir del overlay, apagando el servicio SNI.
    if tray_enabled {
        let (trtx, trrx) = calloop::channel::channel::<tray::TrayCommand>();
        lh.insert_source(trrx, |ev, _, state| {
            if let calloop::channel::Event::Msg(cmd) = ev {
                state.apply_tray_command(cmd);
            }
        })?;
        state.tray = tray::spawn(trtx, theme::list(), config.theme.clone());
        state.sync_tray_status();
    }

    // Socket de control IPC (spec 0003 M1): PING / STATE / QUIT.
    let _ipc_guard = if config.enable_ipc {
        match ipc::bind(target_output_name.as_deref()) {
            Ok((listener, guard)) => {
                let src = calloop::generic::Generic::new(
                    listener,
                    calloop::Interest::READ,
                    calloop::Mode::Level,
                );
                lh.insert_source(src, |_readiness, listener, state: &mut State| {
                    loop {
                        match listener.accept() {
                            Ok((stream, _)) => {
                                if !ipc::same_uid(&stream) {
                                    continue;
                                }
                                if let Ok(req) = ipc::read_request(&stream) {
                                    let reply = state.ipc_reply(&req);
                                    let _ = writeln!(&stream, "{reply}");
                                }
                            }
                            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => break,
                            Err(_) => break,
                        }
                    }
                    Ok(calloop::PostAction::Continue)
                })?;
                Some(guard)
            }
            Err(e) => {
                eprintln!("wayvpet: no se pudo abrir el socket IPC: {e}");
                None
            }
        }
    } else {
        eprintln!("wayvpet: enable_ipc=0; sin socket de control");
        None
    };

    // Tick de animación: recalcula el fotograma y redibuja si cambió. Se
    // reprograma a un instante **exacto** (`State::next_wake`) en vez de a
    // ritmo fijo — sin actividad cae a `IDLE_TICK_CAP` (~5 Hz) en lugar de
    // tickear siempre a `fps` (hasta 120 Hz) sin nada que animar.
    lh.insert_source(Timer::immediate(), |_, _, state| {
        state.tick();
        TimeoutAction::ToInstant(state.next_wake(Instant::now()))
    })?;

    eprintln!("wayvpet: overlay a pantalla completa; Ctrl+C para salir");
    while !state.exit {
        event_loop.dispatch(Some(Duration::from_millis(500)), &mut state)?;
    }
    Ok(())
}

struct State {
    registry_state: RegistryState,
    output_state: OutputState,
    seat_state: SeatState,
    /// Para recrear la región de entrada (vacía normal; rect del gato en edición).
    wl_compositor: wl_compositor::WlCompositor,
    /// Puntero del seat, si lo hay (se guarda para mantenerlo vivo).
    _pointer: Option<wl_pointer::WlPointer>,
    edit: EditState,
    qh: QueueHandle<State>,
    shm: Shm,
    pool: SlotPool,
    layer: LayerSurface,
    config: Config,
    config_path: Option<PathBuf>,
    frames: Frames,
    /// Tema activo cargado de disco, o `None` para el gato embebido.
    theme: Option<theme::LoadedTheme>,
    /// Fotograma actual (0–4), lo decide la máquina de estados.
    frame: u8,
    /// Instantes hasta los que cada pata sigue "bajada".
    left_hold_until: Instant,
    right_hold_until: Instant,
    /// Última pulsación (para el reposo por inactividad).
    last_activity: Instant,
    /// Dirección actual de la mirada hacia el ratón.
    gaze_dir: wayvpet_common::mouse::GazeDirection,
    /// Instante del último evento de mirada recibido.
    last_gaze_at: Instant,
    /// Desplazamiento horizontal relativo por paseo/patrulla del vPet (lógico).
    roam_x: f32,
    /// Dirección del paseo: 1.0 = derecha, -1.0 = izquierda, 0.0 = quieta.
    roam_dir: f32,
    /// Si está rascando la pared al final de la pantalla, instante hasta el que dura.
    scratch_until: Option<Instant>,
    /// Dirección hacia la que estaba rascando (+1.0 derecha, -1.0 izquierda).
    scratch_dir: f32,
    /// Último instante en el que avanzó el paseo.
    last_roam_tick: Instant,
    /// Teclas/minuto en ventana deslizante, para el estado `happy` (spec 0014
    /// M6). Solo cuenta eventos de **teclado**, sin identidad de tecla.
    kpm: crate::kpm::Kpm,
    /// Última recarga de config (para el debounce de 300 ms).
    last_reload: Instant,
    /// Icono de bandeja (spec 0011); `None` si `--no-tray`/`enable_tray=0` o si
    /// no se pudo lanzar el hilo. Al soltarse (fin del overlay) apaga el SNI.
    tray: Option<tray::TrayHandle>,
    /// Último `effective_hidden()` empujado al tray, para no repetir en cada
    /// tick (`sync_tray_status` solo manda al cambiar).
    last_tray_hidden: Option<bool>,
    /// El manager de foreign-toplevel wlr, si el compositor lo soporta (se
    /// guarda solo para mantenerlo vivo).
    _ftl_mgr: Option<ZwlrForeignToplevelManagerV1>,
    /// La lista `ext-foreign-toplevel-list-v1` (camino COSMIC), viva mientras dure.
    _ext_list: Option<ExtForeignToplevelListV1>,
    /// El "info" de COSMIC: se usa para pedir un `zcosmic_toplevel_handle_v1` por
    /// cada toplevel de la lista (`get_cosmic_toplevel`).
    cosmic_info: Option<ZcosmicToplevelInfoV1>,
    /// Toplevels rastreados, por id de objeto. En el camino wlr la clave es el
    /// `zwlr_foreign_toplevel_handle_v1`; en el camino COSMIC, el
    /// `zcosmic_toplevel_handle_v1`.
    toplevels: HashMap<wayland_client::backend::ObjectId, TopInfo>,
    /// Camino COSMIC: id del `ext_foreign_toplevel_handle_v1` → id del
    /// `zcosmic_toplevel_handle_v1`, para poder limpiar al cerrarse la ventana
    /// (el handle COSMIC v2 no emite `closed` propio).
    ext_to_cosmic: HashMap<
        wayland_client::backend::ObjectId,
        (ExtForeignToplevelHandleV1, ZcosmicToplevelHandleV1),
    >,
    /// Estado aplicado: ¿el gato está oculto ahora (ventana a pantalla completa)?
    hidden: bool,
    /// Estado deseado según los toplevels; se aplica a `hidden` tras 350 ms
    /// estable (antirrebote frente a compositores que hacen oscilar el estado).
    want_hidden: bool,
    want_hidden_since: Instant,
    /// Tamaño **lógico** de la capa (el que da el `configure`).
    width: u32,
    height: u32,
    /// Escala HiDPI en base 120 (120 = 1.0×, 180 = 1.5×, 240 = 2.0×). Solo tiene
    /// efecto si hay `viewport` (si no, el búfer va a tamaño lógico).
    scale_120: u32,
    /// `wp_viewport` de la superficie: mapea el búfer físico al tamaño lógico.
    viewport: Option<WpViewport>,
    _fs_mgr: Option<WpFractionalScaleManagerV1>,
    _fs_obj: Option<WpFractionalScaleV1>,
    /// Salida fijada con `--monitor` (se guarda para mantener viva la proxy).
    _target_output: Option<wl_output::WlOutput>,
    /// Claves cambiadas por `SET` de IPC y aún sin `SAVE` al fichero.
    ipc_dirty: std::collections::HashSet<String>,
    /// Anulación manual del ocultado (IPC `SHOW`/`HIDE`/`TOGGLE`): `Some` fuerza
    /// el estado; `None` = seguir la lógica de pantalla completa.
    manual_hidden: Option<bool>,
    exit: bool,
    /// ¿Llegó ya el primer `configure`? Antes no se puede adjuntar búfer
    /// (`zwlr_layer_surface_v1`: error si se ataca antes del ack inicial).
    configured: bool,
}

impl State {
    /// Escala efectiva en base 120. Sin `viewport` no se puede mapear un búfer
    /// físico distinto del lógico, así que se fuerza 120 (1.0×).
    fn eff_scale_120(&self) -> u32 {
        if self.viewport.is_some() {
            self.scale_120
        } else {
            120
        }
    }

    /// Altura del gato en píxeles **físicos** (la config está en lógicos). Manda
    /// `cat_height` del `vpet.ini` del tema si lo trae; si no, el de la config.
    /// La rueda del modo edición limpia ese override (ver `edit_wheel`), así que
    /// tras redimensionar manda la config.
    fn phys_cat_height(&self) -> u32 {
        let h = self
            .theme
            .as_ref()
            .and_then(|t| t.cat_height())
            .map(|h| h as i32)
            .unwrap_or(self.config.cat_height);
        scale_size_120(h.max(1), self.eff_scale_120()).max(1) as u32
    }

    /// Posición del gato dentro del búfer **físico** de `phys_w`×`phys_h`.
    /// Porta el cálculo de `draw_bar`: los offsets del tema o config (lógicos) se
    /// pasan a físicos con `scale_offset_120`.
    fn cat_origin(&self, phys_w: i32, phys_h: i32) -> (i32, i32) {
        let s = self.eff_scale_120();
        let (cw, ch) = (self.frames.w as i32, self.frames.h as i32);
        // Posición: manda el `vpet.ini` del tema si trae el valor; si no, la
        // config. El arrastre libre (modo edición) limpia el override en cuanto
        // agarras el vpet (ver `edit_press`), así que a partir de ahí manda la
        // config y el paseo **no** se detiene: el vpet sigue su conducta y tú
        // lo recolocas.
        let x_off = self
            .theme
            .as_ref()
            .and_then(|t| t.cat_x_offset())
            .unwrap_or(self.config.cat_x_offset);
        let y_off = self
            .theme
            .as_ref()
            .and_then(|t| t.cat_y_offset())
            .unwrap_or(self.config.cat_y_offset);
        let align = self
            .theme
            .as_ref()
            .and_then(|t| t.cat_align())
            .unwrap_or(self.config.cat_align);

        let xoff = scale_offset_120(x_off, s);
        let yoff = scale_offset_120(y_off, s);
        let roam_phys = scale_offset_120(self.roam_x.round() as i32, s);
        // Punto de partida vertical: `Center` (clásico) a media pantalla;
        // `Baseline` (sprite sheets) apoyado en el borde inferior. `cat_y_offset`
        // lo mueve a cualquier altura; se acota para que **siempre** queden al
        // menos 24 px del vpet dentro de la pantalla (que no se pierda).
        let y_base = match self.frames.anchor {
            wayvpet_common::sheet::Anchor::Center => (phys_h - ch) / 2,
            wayvpet_common::sheet::Anchor::Baseline => phys_h - ch,
        };
        let y = (y_base + yoff).clamp(24 - ch, (phys_h - 24).max(0));
        let base_x = match align {
            Align::Center => (phys_w - cw) / 2 + xoff,
            Align::Left => xoff,
            Align::Right => phys_w - cw - xoff,
        };
        let x = (base_x + roam_phys).clamp(10, (phys_w - cw - 10).max(10));
        (x, y)
    }

    /// Anclaje vertical del tema activo (`Center` / `Baseline`); lo usa
    /// `edit_drag` para invertir la base de `cat_origin`.
    fn cat_anchor(&self) -> wayvpet_common::sheet::Anchor {
        self.frames.anchor
    }

    /// Tamaño **físico** del búfer (`phys_w`, `phys_h`), la escala en la que
    /// trabaja `cat_origin`.
    fn phys_size(&self) -> (i32, i32) {
        let s = self.eff_scale_120();
        let pw = scale_size_120(self.width.max(1) as i32, s).max(1);
        let ph = scale_size_120(self.height.max(1) as i32, s).max(1);
        (pw, ph)
    }

    /// Rect **físico** `(x, y, w, h)` del gato en el búfer, tomado de la MISMA
    /// `cat_origin` que dibuja. El hit-test y el arrastre del modo edición lo
    /// usan para no depender de un cálculo paralelo que se desalinea con el
    /// HiDPI o con los `vpet.ini` del tema.
    fn cat_phys_rect(&self) -> (i32, i32, i32, i32) {
        let (pw, ph) = self.phys_size();
        let (ox, oy) = self.cat_origin(pw, ph);
        (ox, oy, self.frames.w as i32, self.frames.h as i32)
    }

    /// Posición del puntero (coordenadas lógicas del protocolo) → píxel físico
    /// del búfer.
    fn ptr_phys(&self, px: f64, py: f64) -> (f64, f64) {
        let s = f64::from(self.eff_scale_120()) / 120.0;
        (px * s, py * s)
    }

    /// Cambia el tema en caliente (IPC `THEME`). `spec` vacío / `embedded` /
    /// `none` → el gato embebido. Marca `theme` como sucia para `SAVE`.
    fn set_theme(&mut self, spec: &str) -> String {
        let spec = match spec {
            "embedded" | "none" | "classic-embedded" => "",
            s => s,
        };
        let loaded = theme::resolve(spec);
        if !spec.is_empty() && loaded.is_none() {
            return format!("ERR el tema '{spec}' no cargó; sigo con el actual");
        }
        self.theme = loaded;
        self.config.theme = spec.to_string();
        self.ipc_dirty.insert("theme".to_string());
        self.roam_x = 0.0;
        self.roam_dir = 0.0;
        self.rerasterize();
        self.draw();
        self.sync_tray_theme();
        format!(
            "OK theme={}",
            if spec.is_empty() { "embedded" } else { spec }
        )
    }

    /// Re-rasteriza los fotogramas del gato a la altura física actual, desde el
    /// tema activo o el embebido. Para un tema de sprite sheet, el cursor de la
    /// máquina de estados se traslada a la caché nueva (no salta a idle).
    fn rerasterize(&mut self) {
        let h = self.phys_cat_height();
        let (mx, my) = (self.config.mirror_x, self.config.mirror_y);
        let prev_cursor = match &self.frames.kind {
            anim::FramesKind::Sheet(sa) => Some(sa.cursor()),
            anim::FramesKind::Classic(_) => None,
        };
        match rasterize_loaded(self.theme.as_ref(), h, mx, my) {
            Ok(mut f) => {
                if let (Some((st, fr)), anim::FramesKind::Sheet(sa)) = (prev_cursor, &mut f.kind) {
                    sa.restore_cursor(st, fr, Instant::now());
                }
                self.frames = f;
            }
            Err(e) => eprintln!("wayvpet: re-rasterizado falló: {e}"),
        }
    }

    /// Reacciona a un cambio de configuración (recarga de fichero o `SET` por
    /// IPC): re-rasteriza si cambió el aspecto del gato, redimensiona/reancla
    /// la barra si hace falta, y redibuja. Común a `reload` y al `SET` en vivo.
    /// `fps` ya no gobierna el ritmo de sondeo (ver [`State::next_wake`]); un
    /// cambio en caliente no necesita reprogramar nada aquí.
    fn apply_config_diff(&mut self, old: &Config) {
        let c = self.config.clone();
        if c.theme != old.theme {
            self.theme = theme::resolve(&c.theme);
            self.sync_tray_theme();
        }
        if c.theme != old.theme
            || c.cat_height != old.cat_height
            || c.mirror_x != old.mirror_x
            || c.mirror_y != old.mirror_y
        {
            self.rerasterize();
        }

        // `overlay_height` / `overlay_position` ya no redimensionan la
        // superficie (ocupa toda la pantalla); solo mueven el vpet dentro, así
        // que basta con redibujar.
        self.draw();
    }

    /// Cambia la escala HiDPI (evento `preferred_scale` o escala de la salida).
    fn set_scale(&mut self, new_120: u32) {
        if new_120 == 0 || new_120 == self.scale_120 {
            return;
        }
        self.scale_120 = new_120;
        if self.viewport.is_some() {
            self.rerasterize();
            eprintln!("wayvpet: escala HiDPI {}/120", new_120);
            self.draw();
        }
    }

    /// Llega un bit de pata del lector de teclado: extiende la ventana de esa
    /// pata y marca actividad. Porta `anim_press_paw` / `anim_take_pending_paws`.
    fn on_paw(&mut self, raw: u8) {
        if let Some(gaze) = wayvpet_common::mouse::gaze_from_byte(raw) {
            let track_mouse = self
                .theme
                .as_ref()
                .map(|t| t.vpet.track_mouse)
                .unwrap_or(true);
            if !track_mouse {
                return;
            }
            let changed = self.gaze_dir != gaze;
            self.gaze_dir = gaze;
            self.last_gaze_at = Instant::now();
            // Nota: el movimiento del ratón NO reinicia last_activity para no
            // impedir que la mascota duerma ni romper su paseo por pantalla.
            if changed {
                self.tick();
            }
            return;
        }

        // `PAW_KEY` marca los eventos de teclado; se separa antes de `apply_mirror`
        // (que solo mira los bits de pata).
        let from_key = raw & paw::PAW_KEY != 0;
        let now = Instant::now();
        if from_key {
            self.kpm.hit(now);
        }

        let vpet = self.theme.as_ref().map(|t| &t.vpet);
        let typing_burst = vpet.map(|v| v.typing_burst).unwrap_or(1);
        let typing_hold_ms = vpet.map(|v| v.typing_hold_ms).unwrap_or(0);

        // Si el vPet requiere una ráfaga continua de tecleo (> 1) para despertar
        // o sacar el instrumento, una tecla suelta (atajo de captura, modifier) se ignora:
        if from_key && typing_burst > 1 {
            let recent = self.kpm.hits_within(Duration::from_millis(1000), now);
            if (recent as u32) < typing_burst {
                return;
            }
        }

        let bit = apply_mirror(raw & paw::PAW_BOTH, self.config.mirror_x);
        let dur_ms = if typing_hold_ms > 0 {
            typing_hold_ms
        } else {
            self.config.keypress_duration.max(0) as u64
        };
        let dur = Duration::from_millis(dur_ms);

        if bit & paw::PAW_LEFT != 0 {
            self.left_hold_until = now + dur;
        }
        if bit & paw::PAW_RIGHT != 0 {
            self.right_hold_until = now + dur;
        }
        self.last_activity = now;
        self.tick(); // respuesta inmediata, no hasta el siguiente tick
    }

    /// Recalcula qué fotograma toca y redibuja si cambió. Porta
    /// `anim_select_frame` para el `classic`; para un tema de sprite sheet
    /// (spec 0014 M2) delega en su máquina de estados (`SheetAnim::tick`).
    fn tick(&mut self) {
        self.apply_pending_hidden();
        let now = Instant::now();
        let dt = now.duration_since(self.last_roam_tick).as_secs_f32();
        self.last_roam_tick = now;

        // Seguimiento de ojos con el ratón (si el vPet lo tiene habilitado)
        let track_mouse = self
            .theme
            .as_ref()
            .map(|t| t.vpet.track_mouse)
            .unwrap_or(true);
        // La mirada vuelve al centro si el vPet no sigue al ratón, o si lleva
        // más de 600 ms sin actualizarse (el cursor se quedó quieto).
        let gaze_expired = self.gaze_dir != wayvpet_common::mouse::GazeDirection::Center
            && now.duration_since(self.last_gaze_at) > Duration::from_millis(600);
        if !track_mouse || gaze_expired {
            self.gaze_dir = wayvpet_common::mouse::GazeDirection::Center;
        }

        let idle_secs = now.duration_since(self.last_activity).as_secs();
        let sleep_timeout_sec = self
            .theme
            .as_ref()
            .and_then(|t| t.vpet.sleep_timeout)
            .unwrap_or(self.config.idle_sleep_timeout_sec as u64);
        let idle_sleep = sleep_timeout_sec > 0 && idle_secs >= sleep_timeout_sec;
        // `boring` (spec 0014 §5.2): inactividad prolongada **antes** del sueño,
        // a mitad del timeout de sueño. Sin ese timeout no hay `boring`.
        let boring = sleep_timeout_sec > 0 && idle_secs >= (sleep_timeout_sec / 2).max(1);

        // Reposo por horario: si `enable_scheduled_sleep` y la hora local cae en
        // la franja `[sleep_begin, sleep_end)`. Porta `anim_is_sleep_time`.
        let scheduled_sleep = self.config.enable_scheduled_sleep
            && local_now_minutes().is_some_and(|m| {
                wayvpet_common::sleep::is_scheduled_sleep(
                    m,
                    self.config.sleep_begin.minutes(),
                    self.config.sleep_end.minutes(),
                )
            });

        let sleeping = idle_sleep || scheduled_sleep;
        let left = now < self.left_hold_until;
        let right = now < self.right_hold_until;
        let idle_f = self.config.idle_frame.clamp(0, 4) as u8;
        let s = self.eff_scale_120();
        let pw = scale_size_120(self.width.max(1) as i32, s).max(1);
        let cw = self.frames.w as i32;
        let x_off = self
            .theme
            .as_ref()
            .and_then(|t| t.cat_x_offset())
            .unwrap_or(self.config.cat_x_offset);
        let xoff = scale_offset_120(x_off, s);
        let cat_align = self
            .theme
            .as_ref()
            .and_then(|t| t.cat_align())
            .unwrap_or(self.config.cat_align);
        let can_roam = self.theme.as_ref().is_some_and(|t| t.can_roam());
        let roam_speed = self.theme.as_ref().map(|t| t.roam_speed()).unwrap_or(45.0);

        let changed = match &mut self.frames.kind {
            anim::FramesKind::Classic(_) => {
                self.roam_dir = 0.0;
                self.roam_x = 0.0;
                let next = if sleeping {
                    FRAME_SLEEPING
                } else {
                    frame_from_paw_state(left, right, idle_f)
                };
                let c = next != self.frame;
                self.frame = next;
                c
            }
            anim::FramesKind::Sheet(sa) => {
                // `happy` (spec 0014 §5.7 M6): teclas/min ≥ `happy_kpm` (0 =
                // desactivado). El estado `happy` solo existe si el tema lo trae;
                // si no, `SheetAnim` cae a su reserva.
                let happy = self.config.happy_kpm > 0
                    && self.kpm.per_minute(now) >= self.config.happy_kpm as usize;

                // Acciones especiales de ocio en reposo configuradas en el vPet activo:
                let vpet = self.theme.as_ref().map(|t| &t.vpet);
                let busy_interrupt = vpet.map(|v| v.busy_interrupt).unwrap_or(true);
                let mut idle_special = if let Some(vp) = vpet {
                    let key_busy = (left || right) && vp.busy_interrupt;
                    let mouse_busy = vp.track_mouse
                        && self.gaze_dir != wayvpet_common::mouse::GazeDirection::Center;
                    if !sleeping
                        && !key_busy
                        && !mouse_busy
                        && !vp.idle_actions.is_empty()
                        && vp.idle_action_interval > 0
                    {
                        let total_cycle = vp.idle_action_interval * vp.idle_actions.len() as u64;
                        let phase = idle_secs % total_cycle;
                        let idx = (phase / vp.idle_action_interval) as usize;
                        let in_action = phase % vp.idle_action_interval;
                        if in_action < vp.idle_action_duration {
                            crate::sheet_anim::StateId::from_theme_name(&vp.idle_actions[idx])
                        } else {
                            None
                        }
                    } else {
                        None
                    }
                } else {
                    None
                };

                // Si está en curso la acción de rascar la pared en los bordes de la pantalla:
                if let Some(until) = self.scratch_until {
                    if now < until
                        && !sleeping
                        && (idle_special.is_none() || !busy_interrupt || (!left && !right))
                    {
                        idle_special = Some(crate::sheet_anim::StateId::Scratch);
                    } else {
                        self.scratch_until = None;
                        if self.scratch_dir != 0.0 {
                            self.roam_dir = -self.scratch_dir;
                        }
                    }
                }

                let mut moved = false;
                let is_walking = idle_special == Some(crate::sheet_anim::StateId::Walk);
                let is_running = idle_special == Some(crate::sheet_anim::StateId::Run);
                let is_scratching = idle_special == Some(crate::sheet_anim::StateId::Scratch);
                let is_moving = (is_walking || is_running) && !is_scratching;

                // El arrastre libre **no** detiene el paseo: `edit_drag` compensa
                // el desplazamiento de `roam_x` para que el vpet siga bajo el
                // cursor mientras lo tienes agarrado, y al soltarlo sigue su ruta.
                if can_roam && is_moving {
                    if self.roam_dir == 0.0 {
                        self.roam_dir = if self.roam_x > 0.0 { -1.0 } else { 1.0 };
                    }
                    let base_x = match cat_align {
                        Align::Center => (pw - cw) / 2 + xoff,
                        Align::Left => xoff,
                        Align::Right => pw - cw - xoff,
                    };
                    let cur_phys = base_x + scale_offset_120(self.roam_x.round() as i32, s);
                    let margin = self
                        .theme
                        .as_ref()
                        .map(|t| t.vpet.roam_margin)
                        .unwrap_or(32);

                    if cur_phys <= margin && self.roam_dir < 0.0 {
                        // Chocó contra el borde izquierdo: se pone a rascar la pantalla antes de virar
                        self.scratch_until = Some(now + Duration::from_millis(2600));
                        self.scratch_dir = -1.0;
                        self.roam_dir = 0.0;
                    } else if cur_phys >= (pw - cw - margin) && self.roam_dir > 0.0 {
                        // Chocó contra el borde derecho: se pone a rascar la pantalla antes de virar
                        self.scratch_until = Some(now + Duration::from_millis(2600));
                        self.scratch_dir = 1.0;
                        self.roam_dir = 0.0;
                    }

                    // En modo correr (Run) el felino se desplaza al doble de velocidad que caminando:
                    let speed_factor = if is_running { 2.1 } else { 1.0 };
                    let step = self.roam_dir * roam_speed * speed_factor * dt.min(0.2);
                    self.roam_x += step;
                    moved = true;
                } else if !is_scratching {
                    self.roam_dir = 0.0;
                }

                // Si la mascota está ocupada con una acción de ocio (caminar, comer RAM)
                // y no debe interrumpirse, las teclas aisladas no la sacan de su pose:
                let pass_left = left && (idle_special.is_none() || busy_interrupt);
                let pass_right = right && (idle_special.is_none() || busy_interrupt);

                let anim_changed = sa.tick(
                    now,
                    sleeping,
                    pass_left,
                    pass_right,
                    happy,
                    boring && !sleeping,
                    self.gaze_dir,
                    idle_special,
                );
                anim_changed || moved
            }
        };

        if changed {
            self.draw();
        }
    }

    /// Cuándo reprogramar el siguiente `tick()` (llamar justo después de uno).
    /// Sin nada pendiente cae a [`IDLE_TICK_CAP`]; con una pata sujeta, un
    /// antirrebote de pantalla completa en curso, o un sprite sheet animando,
    /// se despierta en el instante exacto que le toca — nunca más tarde de lo
    /// que haría falta, y sin sondear de más mientras no hay nada que hacer.
    fn next_wake(&self, now: Instant) -> Instant {
        let fullscreen_deadline = (self.want_hidden != self.hidden)
            .then(|| self.want_hidden_since + Duration::from_millis(350));
        let gaze_deadline = (self.gaze_dir != wayvpet_common::mouse::GazeDirection::Center)
            .then(|| self.last_gaze_at + Duration::from_millis(600));
        let roam_deadline = (self.roam_dir != 0.0).then(|| now + Duration::from_millis(33));
        let sheet_deadline = match &self.frames.kind {
            anim::FramesKind::Sheet(sa) => sa.next_wake(),
            anim::FramesKind::Classic(_) => None,
        };
        next_wake_at(
            now,
            &[
                (self.left_hold_until > now).then_some(self.left_hold_until),
                (self.right_hold_until > now).then_some(self.right_hold_until),
                fullscreen_deadline,
                gaze_deadline,
                roam_deadline,
                sheet_deadline,
            ],
            IDLE_TICK_CAP,
        )
    }

    /// Recarga la configuración desde disco y aplica los cambios en vivo.
    /// Debounce de 300 ms (editores que escriben varias veces seguidas). Si la
    /// nueva config no carga, se mantiene la actual. Porta `config_reload_apply`
    /// y los caminos de `wayland_update_config`. Pendiente: cambio de teclado,
    /// de `layer` y de monitor.
    fn reload(&mut self) {
        let now = Instant::now();
        if now.duration_since(self.last_reload) < Duration::from_millis(300) {
            return;
        }
        self.last_reload = now;

        let Some(path) = self.config_path.clone() else {
            return;
        };
        let loaded = match wayvpet_common::io::load(Some(&path)) {
            Ok(l) => l,
            Err(e) => {
                eprintln!("wayvpet: recarga falló ({e}); se mantiene la configuración");
                return;
            }
        };
        for w in &loaded.warnings {
            eprintln!("wayvpet: aviso: {w}");
        }

        let old = std::mem::replace(&mut self.config, loaded.config);
        self.apply_config_diff(&old);
        eprintln!("wayvpet: configuración recargada");
    }

    /// Recarga el **tema activo desde disco** y re-rasteriza (spec 0006 M6): el
    /// watcher del directorio del tema llega aquí cuando se edita un SVG / PNG.
    /// Comparte el debounce de 300 ms con [`State::reload`].
    fn reload_theme(&mut self) {
        let now = Instant::now();
        if now.duration_since(self.last_reload) < Duration::from_millis(300) {
            return;
        }
        self.last_reload = now;
        if self.config.theme.is_empty() {
            return; // gato embebido: no hay nada en disco que recargar
        }
        self.theme = theme::resolve(&self.config.theme);
        self.rerasterize();
        self.draw();
        eprintln!("wayvpet: tema recargado desde disco");
    }

    /// Empuja al icono del tray el estado `Normal`/`Hidden` si cambió desde la
    /// última vez (spec 0011 §"Estado del icono", M2 parcial — `Error` queda
    /// para cuando exista supervisión real de la surface). No hace nada sin
    /// tray activo ni si `effective_hidden()` no cambió.
    fn sync_tray_status(&mut self) {
        let Some(handle) = &self.tray else { return };
        let hidden = self.effective_hidden();
        if self.last_tray_hidden == Some(hidden) {
            return;
        }
        self.last_tray_hidden = Some(hidden);
        handle.set_status(if hidden {
            tray::TrayStatus::Hidden
        } else {
            tray::TrayStatus::Normal
        });
    }

    /// Empuja al submenú "Tema" del tray cuál es el activo ahora
    /// (`self.config.theme`) — sin esto, el marcado (●) del menú se queda
    /// congelado en el tema con el que arrancó el proceso. Se llama tras
    /// cualquier cambio real: clic en el propio tray, IPC `THEME`/`SET theme`,
    /// o recarga de config.
    fn sync_tray_theme(&self) {
        if let Some(handle) = &self.tray {
            handle.set_active_theme(self.config.theme.clone());
        }
    }

    /// Empuja al tray si el modo edición está activo, para el `✓` del ítem
    /// "Modo edición" — llamado desde el único sitio que cambia `edit.active`
    /// ([`State::edit_set`]), así que cubre tanto el clic en el propio tray
    /// como `EDIT on|off|toggle` por IPC/`wayvpetctl`.
    fn sync_tray_edit(&self) {
        if let Some(handle) = &self.tray {
            handle.set_edit_active(self.edit.active);
        }
    }

    /// Ejecuta un [`tray::TrayCommand`] (clic en el menú del icono, spec 0011).
    /// Cada rama reutiliza la misma lógica que el verbo IPC equivalente.
    fn apply_tray_command(&mut self, cmd: tray::TrayCommand) {
        use tray::TrayCommand as C;
        match cmd {
            C::ToggleVisibility => {
                self.manual_hidden = Some(!self.effective_hidden());
                self.draw();
                self.sync_tray_status();
            }
            // Igual que IPC `EDIT toggle`: al salir (persist=true) guarda la
            // posición/tamaño si cambiaron. `edit_set` ya empuja el `✓` del
            // menú (`sync_tray_edit`), así que no hace falta repetirlo aquí.
            C::ToggleEdit => {
                let on = !self.edit.active;
                self.edit_set(on, !on);
            }
            // M1: re-rasteriza y redibuja. El teardown+rebuild completo de las
            // surfaces con reintentos es M2.
            C::RestartOverlays => {
                self.rerasterize();
                self.draw();
                eprintln!("wayvpet: overlay re-rasterizado (tray)");
            }
            C::LaunchConfig => tray::launch_config(),
            C::Reload => {
                if self.config_path.is_some() {
                    self.reload();
                }
            }
            C::SetTheme(name) => {
                let r = self.set_theme(&name);
                eprintln!("wayvpet: tray → tema {name}: {r}");
            }
            C::About => eprintln!(
                "wayvpet {} — https://github.com/athomo001/wayvpet",
                env!("CARGO_PKG_VERSION")
            ),
            C::Quit => self.exit = true,
        }
    }

    /// Recalcula el estado *deseado* de ocultar: algún toplevel activado y a
    /// pantalla completa (y `disable_fullscreen_hide` desactivado). No dibuja: el
    /// cambio se aplica desde `apply_pending_hidden` con antirrebote. Para un
    /// solo monitor no hace falta mirar en qué salida está. Porta
    /// `fs_recompute_state` con el fallback global de `fullscreen.c`.
    fn recompute_hidden(&mut self) {
        let want = !self.config.disable_fullscreen_hide
            && self.toplevels.values().any(|t| t.fullscreen && t.activated);
        if want != self.want_hidden {
            self.want_hidden = want;
            self.want_hidden_since = Instant::now();
        }
    }

    /// Aplica ocultar/mostrar por pantalla completa con un antirrebote de
    /// 350 ms. Algunos compositores (visto en cosmic-comp 1.0) hacen oscilar el
    /// estado de pantalla completa de las ventanas; sin esto el gato
    /// parpadearía. Se llama desde `tick` (cada fotograma).
    fn apply_pending_hidden(&mut self) {
        if self.want_hidden == self.hidden {
            return;
        }
        if Instant::now().duration_since(self.want_hidden_since) < Duration::from_millis(350) {
            return;
        }
        self.hidden = self.want_hidden;
        eprintln!(
            "wayvpet: pantalla completa {}",
            if self.hidden {
                "detectada — gato oculto"
            } else {
                "despejada"
            }
        );
        self.draw();
        self.sync_tray_status();
    }

    /// ¿Está el gato oculto ahora mismo? Anulación manual sobre la lógica de
    /// pantalla completa.
    fn effective_hidden(&self) -> bool {
        self.manual_hidden.unwrap_or(self.hidden)
    }

    /// Entra o sale del modo edición (spec 0005). Al salir con `persist`, si los
    /// `cat_*_offset` / `cat_height` cambiaron, se guardan al `.conf` (con
    /// `ConfDoc`, sin tocar el resto).
    fn edit_set(&mut self, active: bool, persist: bool) -> String {
        if active != self.edit.active {
            self.edit.active = active;
            self.edit.dragging = false;
            if active {
                // Arrastre libre: **no** se toca la posición ni el paseo al
                // entrar; el vpet sigue haciendo lo suyo. La primera vez que lo
                // agarras, `edit_press` pasa el valor efectivo a la config y
                // limpia el override del `vpet.ini` para que el arrastre se vea.
                self.edit.snapshot = (
                    self.config.cat_x_offset,
                    self.config.cat_y_offset,
                    self.config.cat_height,
                );
                self.layer
                    .set_keyboard_interactivity(KeyboardInteractivity::OnDemand);
            } else {
                self.layer
                    .set_keyboard_interactivity(KeyboardInteractivity::None);
                let now = (
                    self.config.cat_x_offset,
                    self.config.cat_y_offset,
                    self.config.cat_height,
                );
                if persist && now != self.edit.snapshot {
                    for k in ["cat_x_offset", "cat_y_offset", "cat_height"] {
                        self.ipc_dirty.insert(k.to_string());
                    }
                    eprintln!("wayvpet: arrastre libre — {}", self.ipc_save());
                }
            }
            self.layer.commit();
            self.draw(); // recoloca la región de entrada
            self.sync_tray_edit();
            eprintln!(
                "wayvpet: arrastre libre {} — rect del gato (físico) = {:?}",
                if active { "ON" } else { "OFF" },
                self.cat_phys_rect()
            );
        }
        format!("OK edit={}", if active { "on" } else { "off" })
    }

    /// Botón izquierdo dentro del gato: empezar a arrastrar. Todo en píxeles
    /// **físicos** (el puntero llega en lógicas y se convierte), contra el mismo
    /// rect que dibuja `cat_origin`.
    fn edit_press(&mut self, px: f64, py: f64) {
        let (fx, fy) = self.ptr_phys(px, py);
        let rect = self.cat_phys_rect();
        if wayvpet_common::edit::hit(rect, fx.round() as i32, fy.round() as i32) {
            self.edit.dragging = true;
            self.edit.grab_dx = fx - f64::from(rect.0);
            self.edit.grab_dy = fy - f64::from(rect.1);
            // A partir de aquí el arrastre escribe `config.cat_*_offset`: pasa el
            // valor efectivo actual a la config y quita el override del `vpet.ini`
            // para que el gato se mueva bajo el cursor de inmediato (si no, no se
            // vería hasta soltar).
            let seed = self
                .theme
                .as_ref()
                .map(|t| (t.cat_x_offset(), t.cat_y_offset()));
            if let Some((xo, yo)) = seed {
                if let Some(v) = xo {
                    self.config.cat_x_offset = v;
                }
                if let Some(v) = yo {
                    self.config.cat_y_offset = v;
                }
            }
            if let Some(t) = self.theme.as_mut() {
                t.vpet.cat_x_offset = None;
                t.vpet.cat_y_offset = None;
            }
        }
        self.edit.ptr = (fx, fy); // en físicas, como grab_dx/dy
    }

    /// Movimiento con el gato agarrado: recalcula `cat_x_offset` / `cat_y_offset`
    /// invirtiendo `cat_origin` (base de alineación/anclaje en físicas → lógicas).
    fn edit_drag(&mut self, px: f64, py: f64) {
        let (fx, fy) = self.ptr_phys(px, py);
        self.edit.ptr = (fx, fy);
        let (pw, ph) = self.phys_size();
        let (_, _, cw, ch) = self.cat_phys_rect();
        // Origen físico deseado = puntero menos el punto de agarre, acotado igual
        // que `cat_origin` para que lo que se ve no se despegue de la config.
        let ox = ((fx - self.edit.grab_dx).round() as i32).clamp(10, (pw - cw - 10).max(10));
        let oy = ((fy - self.edit.grab_dy).round() as i32).clamp(24 - ch, (ph - 24).max(0));
        let s = self.eff_scale_120();
        // `cat_origin` suma `roam_x` a la X, así que para dejar el vpet **bajo el
        // cursor** hay que descontarlo: si el vpet está paseando, seguirá bajo el
        // ratón mientras lo tengas agarrado.
        let roam_phys = scale_offset_120(self.roam_x.round() as i32, s);
        let ox_base = ox - roam_phys;
        let xoff_phys = match self.config.cat_align {
            Align::Left => ox_base,
            Align::Center => ox_base - (pw - cw) / 2,
            Align::Right => (pw - cw) - ox_base,
        };
        let y_base = match self.cat_anchor() {
            wayvpet_common::sheet::Anchor::Center => (ph - ch) / 2,
            wayvpet_common::sheet::Anchor::Baseline => ph - ch,
        };
        self.config.cat_x_offset = unscale_offset_120(xoff_phys, s);
        self.config.cat_y_offset = unscale_offset_120(oy - y_base, s);
        self.draw();
    }

    /// Rueda en modo edición: cambia `cat_height` (con recache). Si se está
    /// arrastrando, re-ancla el agarre para que el gato "crezca bajo el cursor".
    fn edit_wheel(&mut self, step: i32) {
        // Parte de la altura efectiva actual (la del `vpet.ini` si el tema la
        // trae) y, al cambiarla, quita ese override para que la rueda mande.
        let cur = self
            .theme
            .as_ref()
            .and_then(|t| t.cat_height())
            .map_or(self.config.cat_height, |h| h as i32);
        let new_h = wayvpet_common::edit::resize_cat_height(cur, step);
        if new_h == cur {
            return;
        }
        self.config.cat_height = new_h;
        if let Some(t) = self.theme.as_mut() {
            t.vpet.cat_height = None;
        }
        self.rerasterize();
        if self.edit.dragging {
            let (rx, ry, ..) = self.cat_phys_rect();
            self.edit.grab_dx = self.edit.ptr.0 - f64::from(rx);
            self.edit.grab_dy = self.edit.ptr.1 - f64::from(ry);
        }
        self.draw();
    }

    /// Responde a una petición del socket de control (spec 0003 M1–M3, 0011).
    /// Verbos: `PING`, `STATE`, `GET clave`, `SET clave valor` (en vivo),
    /// `SAVE`, `RELOAD`, `SHOW`/`HIDE`/`TOGGLE`/`AUTO`, `QUIT`.
    fn ipc_reply(&mut self, req: &str) -> String {
        let mut parts = req.splitn(3, char::is_whitespace);
        let verb = parts.next().unwrap_or("").to_ascii_uppercase();
        let arg1 = parts.next().unwrap_or("").trim();
        let arg2 = parts.next().unwrap_or("").trim();

        match verb.as_str() {
            "PING" => "PONG".to_string(),
            "STATE" => format!(
                "pid={} frame={} sheet={} hidden={} manual_hidden={} edit={} theme={} scale_120={} \
                 fps={} width={} height={} cat_height={} cat_opacity={} roaming={}",
                std::process::id(),
                self.frame,
                match &self.frames.kind {
                    anim::FramesKind::Sheet(sa) => {
                        let (st, fr) = sa.debug_pos();
                        format!("{st}:{fr}")
                    }
                    anim::FramesKind::Classic(_) => "-".to_string(),
                },
                self.effective_hidden(),
                match self.manual_hidden {
                    Some(true) => "hide",
                    Some(false) => "show",
                    None => "auto",
                },
                self.edit.active,
                if self.config.theme.is_empty() {
                    "embedded"
                } else {
                    &self.config.theme
                },
                self.scale_120,
                self.config.fps,
                self.width,
                self.height,
                self.config.cat_height,
                self.config.cat_opacity,
                // ¿el vpet activo se pasea solo? La ventana de config oculta los
                // campos de posición cuando es así (se recoloca arrastrando).
                u8::from(self.theme.as_ref().is_some_and(|t| t.can_roam())),
            ),
            "SNAPSHOT" | "SCREENSHOT" => {
                let path_str = if arg1.is_empty() {
                    "wayvpet_snapshot.png"
                } else {
                    arg1
                };
                let path = std::path::Path::new(path_str);
                let (fw, fh) = (self.frames.w, self.frames.h);
                let bgra = self.frames.current(self.frame);
                match save_frame_as_png(bgra, fw, fh, path) {
                    Ok(()) => format!("OK {}", path.display()),
                    Err(e) => format!("ERR {e}"),
                }
            }
            // Miniatura de un tema: rasteriza un fotograma a 128 px y lo guarda
            // como PNG bajo `$XDG_RUNTIME_DIR`. La ventana `wayvpet-config` la
            // usa para la galería. `THUMB` a secas = el tema activo.
            "THUMB" => {
                let spec = match arg1 {
                    "" => self.config.theme.as_str(),
                    "embedded" | "none" => "",
                    s => s,
                };
                let loaded = if spec.is_empty() {
                    None
                } else {
                    match theme::resolve(spec) {
                        Some(l) => Some(l),
                        None => return format!("ERR el tema '{spec}' no cargó"),
                    }
                };
                match rasterize_loaded(loaded.as_ref(), 128, false, false) {
                    Ok(frames) => {
                        let slug: String = arg1
                            .chars()
                            .map(|c| if c.is_ascii_alphanumeric() { c } else { '_' })
                            .collect();
                        let dir = std::env::var_os("XDG_RUNTIME_DIR")
                            .map(std::path::PathBuf::from)
                            .unwrap_or_else(std::env::temp_dir);
                        let path = dir.join(format!("wayvpet-thumb-{slug}.png"));
                        match save_frame_as_png(frames.current(0), frames.w, frames.h, &path) {
                            Ok(()) => format!("OK {}", path.display()),
                            Err(e) => format!("ERR {e}"),
                        }
                    }
                    Err(e) => format!("ERR {e}"),
                }
            }
            "GET" if !arg1.is_empty() => {
                match wayvpet_common::config::ConfDoc::parse(&self.config.to_ini()).get(arg1) {
                    Some(v) => v.to_string(),
                    None => format!("ERR clave desconocida: {arg1}"),
                }
            }
            "SET" if !arg1.is_empty() && !arg2.is_empty() => {
                let old = self.config.clone();
                match wayvpet_common::config::set_live(&mut self.config, arg1, arg2) {
                    Ok(warnings) => {
                        // Un `SET` explícito de posición/tamaño/alineación gana
                        // sobre el `vpet.ini` del tema: si no, los deslizadores de
                        // la ventana no harían nada con un tema de sprite sheet
                        // (`cat_origin` prefiere el override del tema). Igual que
                        // al salir del modo edición (ver `edit_set`).
                        if let Some(t) = self.theme.as_mut() {
                            // Un `SET` explícito gana al valor sugerido por el
                            // `vpet.ini`, pero **no** cambia su conducta: un vpet
                            // que se pasea sigue paseándose (el usuario lo
                            // recoloca arrastrando, no con estos campos).
                            match arg1 {
                                "cat_x_offset" => t.vpet.cat_x_offset = None,
                                "cat_y_offset" => t.vpet.cat_y_offset = None,
                                "cat_height" => t.vpet.cat_height = None,
                                "cat_align" => t.vpet.cat_align = None,
                                _ => {}
                            }
                        }
                        self.apply_config_diff(&old);
                        self.ipc_dirty.insert(arg1.to_string());
                        if warnings.is_empty() {
                            format!("OK {arg1}={arg2}")
                        } else {
                            format!("OK {} (ajustado: {})", arg1, warnings.join("; "))
                        }
                    }
                    Err(e) => format!("ERR {e}"),
                }
            }
            "GET" | "SET" => "ERR uso: GET clave | SET clave valor".to_string(),
            // Config viva completa como INI (una línea por clave, `\n` reales).
            // La usa la ventana `wayvpet-config` (spec 0007) para cargar su
            // modelo de un tirón en vez de `GET` clave por clave.
            "DUMP" => self.config.to_ini(),
            // Nombres de las salidas conectadas, separados por espacio. La
            // ventana `wayvpet-config` (spec 0007) rellena con esto el selector
            // de monitor.
            "OUTPUTS" => {
                let mut names: Vec<String> = self
                    .output_state
                    .outputs()
                    .filter_map(|o| self.output_state.info(&o).and_then(|i| i.name))
                    .collect();
                names.sort();
                names.dedup();
                names.join(" ")
            }
            // Presets (spec 0008 §8.2): `PRESET list` o `PRESET <nombre>` para
            // aplicar un `.conf` parcial por encima de la config activa.
            "PRESET" => match arg1 {
                "" | "list" => wayvpet_common::config::presets::list().join(" "),
                name => match wayvpet_common::config::presets::load(name) {
                    Ok(pairs) => {
                        let old = self.config.clone();
                        let mut n = 0;
                        let mut warns: Vec<String> = Vec::new();
                        for (k, v) in pairs {
                            match wayvpet_common::config::set_live(&mut self.config, &k, &v) {
                                Ok(w) => {
                                    self.ipc_dirty.insert(k.clone());
                                    warns.extend(w);
                                    n += 1;
                                }
                                Err(e) => warns.push(format!("{k}: {e}")),
                            }
                        }
                        // Un `SET` de posición/tamaño limpia el override del
                        // `vpet.ini` (ver el arm "SET"); aquí basta con redibujar.
                        if let Some(t) = self.theme.as_mut() {
                            if self.ipc_dirty.contains("cat_x_offset") {
                                t.vpet.cat_x_offset = None;
                            }
                            if self.ipc_dirty.contains("cat_y_offset") {
                                t.vpet.cat_y_offset = None;
                            }
                            if self.ipc_dirty.contains("cat_height") {
                                t.vpet.cat_height = None;
                            }
                        }
                        self.apply_config_diff(&old);
                        if warns.is_empty() {
                            format!("OK preset {name} ({n} claves)")
                        } else {
                            format!("OK preset {name} ({n} claves; {})", warns.join("; "))
                        }
                    }
                    Err(e) => format!("ERR {e}"),
                },
            },
            // Perfiles (spec 0008 §8.3): configuraciones completas con nombre.
            "PROFILE" => {
                use wayvpet_common::config::profiles;
                let Some(conf) = self.config_path.clone() else {
                    return "ERR sin fichero de configuración".to_string();
                };
                match arg1 {
                    "" | "list" => {
                        let mut l = profiles::list(&conf);
                        if let Some(a) = profiles::active() {
                            // marca el activo con '*'
                            for n in &mut l {
                                if *n == a {
                                    *n = format!("*{n}");
                                }
                            }
                        }
                        l.join(" ")
                    }
                    "active" => profiles::active().unwrap_or_default(),
                    "save" if !arg2.is_empty() => {
                        match profiles::save(&conf, arg2, &self.config.to_ini()) {
                            Ok(()) => format!("OK perfil {arg2} guardado"),
                            Err(e) => format!("ERR {e}"),
                        }
                    }
                    "switch" if !arg2.is_empty() => match profiles::switch(&conf, arg2) {
                        Ok(()) => {
                            self.reload();
                            format!("OK perfil {arg2}")
                        }
                        Err(e) => format!("ERR {e}"),
                    },
                    _ => "ERR uso: PROFILE list | active | save <n> | switch <n>".to_string(),
                }
            }
            "THEME" => match arg1 {
                "" => "ERR uso: THEME list | next | <nombre>".to_string(),
                "list" => {
                    let mut l = theme::list();
                    l.insert(0, "embedded".to_string());
                    l.join(" ")
                }
                "next" => {
                    let all = theme::list();
                    if all.is_empty() {
                        return "ERR no hay temas instalados".to_string();
                    }
                    let cur = self.config.theme.clone();
                    let next = match all.iter().position(|n| *n == cur) {
                        Some(i) => all[(i + 1) % all.len()].clone(),
                        None => all[0].clone(),
                    };
                    self.set_theme(&next)
                }
                name => self.set_theme(name),
            },
            "EDIT" => match match arg1 {
                "on" => Some(true),
                "off" => Some(false),
                "toggle" | "" => Some(!self.edit.active),
                _ => None,
            } {
                Some(on) => self.edit_set(on, !on), // al apagar, persiste
                None => "ERR uso: EDIT on|off|toggle".to_string(),
            },
            "SHOW" | "HIDE" | "TOGGLE" | "AUTO" => {
                self.manual_hidden = match verb.as_str() {
                    "SHOW" => Some(false),
                    "HIDE" => Some(true),
                    "TOGGLE" => Some(!self.effective_hidden()),
                    _ => None, // AUTO: vuelve a seguir la pantalla completa
                };
                self.draw();
                self.sync_tray_status();
                format!(
                    "OK {}",
                    if self.effective_hidden() {
                        "hidden"
                    } else {
                        "shown"
                    }
                )
            }
            "SAVE" => self.ipc_save(),
            "RELOAD" => {
                if self.config_path.is_some() {
                    self.reload();
                    "OK".to_string()
                } else {
                    "ERR sin fichero de configuración".to_string()
                }
            }
            "QUIT" => {
                self.exit = true;
                "OK".to_string()
            }
            "" => "ERR petición vacía".to_string(),
            other => format!("ERR comando desconocido: {other}"),
        }
    }

    /// `SAVE`: vuelca al `.conf` **solo las claves cambiadas por `SET`** desde el
    /// último guardado, con `ConfDoc` para no tocar comentarios ni el resto de
    /// líneas. Escritura atómica.
    fn ipc_save(&mut self) -> String {
        let Some(path) = self.config_path.clone() else {
            return "ERR sin fichero de configuración".to_string();
        };
        if self.ipc_dirty.is_empty() {
            return "OK (nada que guardar)".to_string();
        }
        let text = std::fs::read_to_string(&path).unwrap_or_default();
        let mut doc = wayvpet_common::config::ConfDoc::parse(&text);
        let ini = wayvpet_common::config::ConfDoc::parse(&self.config.to_ini());
        for key in &self.ipc_dirty {
            if let Some(v) = ini.get(key) {
                doc.set(key, v);
            }
        }
        match wayvpet_common::io::save_atomic(&path, &doc.render()) {
            Ok(()) => {
                let n = self.ipc_dirty.len();
                self.ipc_dirty.clear();
                self.last_reload = Instant::now(); // no re-disparar la recarga por el watcher
                format!("OK ({n} clave(s) guardada(s))")
            }
            Err(e) => format!("ERR no se pudo escribir {}: {e}", path.display()),
        }
    }

    /// Limpia el buffer (transparente) y dibuja el fotograma actual del gato.
    ///
    /// El búfer se crea en píxeles **físicos** (`lógico × escala/120`); si hay
    /// `wp_viewport`, se le fija como destino el tamaño **lógico** para que el
    /// compositor lo reescale sin pérdida en pantallas HiDPI. A escala 1.0× (o
    /// sin viewport) físico == lógico y todo es idéntico al camino sin HiDPI.
    fn draw(&mut self) {
        // No adjuntar búfer antes del primer `configure` (protocolo layer-shell).
        // El estado interno sí avanza; se pintará al llegar el `configure`.
        if !self.configured {
            return;
        }
        let (lw, lh) = (self.width.max(1), self.height.max(1));
        let s = self.eff_scale_120();
        let pw = scale_size_120(lw as i32, s).max(1) as u32;
        let ph = scale_size_120(lh as i32, s).max(1) as u32;
        let stride = pw as i32 * 4;
        let needed = (pw * ph * 4) as usize;
        // Se calculan antes de tocar el pool (evita conflictos de préstamo).
        let (ox, oy) = self.cat_origin(pw as i32, ph as i32);
        let (fw, fh) = (self.frames.w, self.frames.h);
        let hidden = self.effective_hidden();
        let frame = self.frames.current(self.frame);

        if let Err(e) = self.pool.resize(needed.max(1)) {
            eprintln!("wayvpet: no se pudo redimensionar el pool a {needed}: {e}");
            return;
        }
        let (buffer, canvas) =
            match self
                .pool
                .create_buffer(pw as i32, ph as i32, stride, wl_shm::Format::Argb8888)
            {
                Ok(x) => x,
                Err(e) => {
                    eprintln!("wayvpet: create_buffer {pw}x{ph} falló: {e}");
                    return;
                }
            };

        // Fondo siempre transparente: la superficie ocupa toda la pantalla, un
        // tinte a pantalla completa nunca es lo que se quiere para un vpet.
        canvas.fill(0);
        if !hidden {
            // Opacidad del gato: % (0–100) → factor 0–255 para el blit.
            let cat_op = (self.config.cat_opacity.clamp(0, 100) * 255 / 100) as u8;
            let flip_on_walk = self
                .theme
                .as_ref()
                .map(|t| t.vpet.flip_on_walk)
                .unwrap_or(true);
            let flip_h = if flip_on_walk
                && (self.roam_dir < 0.0 || (self.scratch_until.is_some() && self.scratch_dir < 0.0))
            {
                !self.config.mirror_x
            } else {
                self.config.mirror_x
            };
            anim::blit_over_flip(canvas, (pw, ph), frame, (fw, fh), (ox, oy), cat_op, flip_h);
        }

        // El viewport traduce el búfer físico al tamaño lógico de la superficie.
        if let Some(vp) = &self.viewport {
            vp.set_destination(lw as i32, lh as i32);
        }

        // Región de entrada: vacía (click-through) normalmente. En modo edición,
        // **solo el gato + un margen** para poder arrastrarlo sin que el cursor
        // se escape — NUNCA toda la superficie: como ahora ocupa la pantalla
        // entera, eso se tragaría el ratón de todo el escritorio. Va en
        // coordenadas lógicas de la superficie, así que el rect físico del gato
        // se convierte con `unscale_offset_120`.
        let region = self.wl_compositor.create_region(&self.qh, ());
        if self.edit.active {
            let lx = unscale_offset_120(ox, s);
            let ly = unscale_offset_120(oy, s);
            let lrw = unscale_offset_120(fw as i32, s).max(1);
            let lrh = unscale_offset_120(fh as i32, s).max(1);
            let m = 48; // margen lógico para no perder el arrastre
            let x0 = (lx - m).max(0);
            let y0 = (ly - m).max(0);
            let x1 = (lx + lrw + m).min(lw as i32);
            let y1 = (ly + lrh + m).min(lh as i32);
            if x1 > x0 && y1 > y0 {
                region.add(x0, y0, x1 - x0, y1 - y0);
            }
        }
        self.layer.wl_surface().set_input_region(Some(&region));
        region.destroy();

        let surface = self.layer.wl_surface();
        surface.damage_buffer(0, 0, pw as i32, ph as i32);
        if let Err(e) = buffer.attach_to(surface) {
            eprintln!("wayvpet: attach falló: {e}");
        }
        surface.frame(&self.qh, surface.clone());
        self.layer.commit();
    }
}

impl LayerShellHandler for State {
    fn closed(&mut self, _conn: &Connection, _qh: &QueueHandle<Self>, _layer: &LayerSurface) {
        eprintln!("wayvpet: el compositor cerró la surface");
        self.exit = true;
    }

    fn configure(
        &mut self,
        _conn: &Connection,
        _qh: &QueueHandle<Self>,
        _layer: &LayerSurface,
        configure: LayerSurfaceConfigure,
        _serial: u32,
    ) {
        // El compositor nos da el tamaño definitivo (0 = "elige tú").
        let (cw, ch) = configure.new_size;
        eprintln!("wayvpet: configure new_size=({cw},{ch})");
        if cw != 0 {
            self.width = cw;
        }
        if ch != 0 {
            self.height = ch;
        }
        self.configured = true; // desde aquí ya se puede adjuntar búfer
        self.draw();
    }
}

impl CompositorHandler for State {
    fn scale_factor_changed(
        &mut self,
        _c: &Connection,
        _qh: &QueueHandle<Self>,
        _s: &wl_surface::WlSurface,
        _new: i32,
    ) {
    }
    fn transform_changed(
        &mut self,
        _c: &Connection,
        _qh: &QueueHandle<Self>,
        _s: &wl_surface::WlSurface,
        _t: wl_output::Transform,
    ) {
    }
    fn frame(
        &mut self,
        _c: &Connection,
        qh: &QueueHandle<Self>,
        _s: &wl_surface::WlSurface,
        _time: u32,
    ) {
        // Sin animación aún: no repintamos en cada frame.
        let _ = qh;
    }
    fn surface_enter(
        &mut self,
        _c: &Connection,
        _qh: &QueueHandle<Self>,
        _s: &wl_surface::WlSurface,
        o: &wl_output::WlOutput,
    ) {
        // Sin fractional-scale: usar la escala **entera** de la salida donde
        // entró la superficie (fallback de `scale_120_from_output` del C).
        if self._fs_obj.is_none() {
            if let Some(info) = self.output_state.info(o) {
                if info.scale_factor > 0 {
                    self.set_scale(info.scale_factor as u32 * 120);
                }
            }
        }
    }
    fn surface_leave(
        &mut self,
        _c: &Connection,
        _qh: &QueueHandle<Self>,
        _s: &wl_surface::WlSurface,
        _o: &wl_output::WlOutput,
    ) {
    }
}

impl OutputHandler for State {
    fn output_state(&mut self) -> &mut OutputState {
        &mut self.output_state
    }
    fn new_output(&mut self, _c: &Connection, _qh: &QueueHandle<Self>, _o: wl_output::WlOutput) {}
    fn update_output(&mut self, _c: &Connection, _qh: &QueueHandle<Self>, _o: wl_output::WlOutput) {
    }
    fn output_destroyed(
        &mut self,
        _c: &Connection,
        _qh: &QueueHandle<Self>,
        _o: wl_output::WlOutput,
    ) {
    }
}

impl ShmHandler for State {
    fn shm_state(&mut self) -> &mut Shm {
        &mut self.shm
    }
}

impl ProvidesRegistryState for State {
    fn registry(&mut self) -> &mut RegistryState {
        &mut self.registry_state
    }
    registry_handlers![OutputState, SeatState];
}

delegate_compositor!(State);
delegate_output!(State);
delegate_shm!(State);
delegate_layer!(State);
delegate_registry!(State);
delegate_seat!(State);
delegate_pointer!(State);
// wl_region no tiene eventos: solo la usamos para la región de entrada.
delegate_noop!(State: ignore wl_region::WlRegion);

// ── Modo edición con ratón (spec 0005 M2–M4, M6) ────────────────────────────
impl SeatHandler for State {
    fn seat_state(&mut self) -> &mut SeatState {
        &mut self.seat_state
    }
    fn new_seat(&mut self, _: &Connection, _: &QueueHandle<Self>, _: wl_seat::WlSeat) {}
    fn new_capability(
        &mut self,
        _: &Connection,
        qh: &QueueHandle<Self>,
        seat: wl_seat::WlSeat,
        cap: Capability,
    ) {
        if cap == Capability::Pointer && self._pointer.is_none() {
            match self.seat_state.get_pointer(qh, &seat) {
                Ok(p) => {
                    self._pointer = Some(p);
                    eprintln!("wayvpet: puntero del seat listo (modo edición disponible)");
                }
                Err(e) => eprintln!("wayvpet: sin puntero para el modo edición: {e}"),
            }
        }
    }
    fn remove_capability(
        &mut self,
        _: &Connection,
        _: &QueueHandle<Self>,
        _: wl_seat::WlSeat,
        cap: Capability,
    ) {
        if cap == Capability::Pointer {
            self._pointer = None;
        }
    }
    fn remove_seat(&mut self, _: &Connection, _: &QueueHandle<Self>, _: wl_seat::WlSeat) {}
}

impl PointerHandler for State {
    fn pointer_frame(
        &mut self,
        _: &Connection,
        _: &QueueHandle<Self>,
        _pointer: &wl_pointer::WlPointer,
        events: &[PointerEvent],
    ) {
        if !self.edit.active {
            return;
        }
        let surface = self.layer.wl_surface().clone();
        for ev in events {
            if ev.surface != surface {
                continue;
            }
            let (px, py) = ev.position;
            match ev.kind {
                PointerEventKind::Press { button, .. } if button == BTN_LEFT => {
                    self.edit_press(px, py);
                }
                PointerEventKind::Release { button, .. } if button == BTN_LEFT => {
                    self.edit.dragging = false;
                }
                PointerEventKind::Leave { .. } => {
                    self.edit.dragging = false; // por si el cursor se sale
                }
                PointerEventKind::Motion { .. } if self.edit.dragging => {
                    self.edit_drag(px, py);
                }
                PointerEventKind::Axis { vertical, .. } => {
                    let dir = if vertical.absolute < 0.0 { 1 } else { -1 };
                    self.edit_wheel(dir * wayvpet_common::edit::wheel_step(false));
                }
                _ => {}
            }
        }
    }
}
// HiDPI: el manager y el viewporter no emiten eventos; el viewport tampoco.
delegate_noop!(State: ignore WpViewporter);
delegate_noop!(State: ignore WpViewport);
delegate_noop!(State: ignore WpFractionalScaleManagerV1);

/// `wp_fractional_scale_v1::preferred_scale`: escala sugerida en /120.
impl Dispatch<WpFractionalScaleV1, ()> for State {
    fn event(
        state: &mut Self,
        _obj: &WpFractionalScaleV1,
        event: fs_v1::Event,
        _: &(),
        _conn: &Connection,
        _qh: &QueueHandle<Self>,
    ) {
        if let fs_v1::Event::PreferredScale { scale } = event {
            state.set_scale(scale);
        }
    }
}

// ── foreign-toplevel-management: detección de pantalla completa ──────────────
impl Dispatch<ZwlrForeignToplevelManagerV1, ()> for State {
    fn event(
        state: &mut Self,
        _mgr: &ZwlrForeignToplevelManagerV1,
        event: ftl_mgr::Event,
        _: &(),
        _conn: &Connection,
        _qh: &QueueHandle<Self>,
    ) {
        match event {
            ftl_mgr::Event::Toplevel { toplevel } => {
                state.toplevels.insert(toplevel.id(), TopInfo::default());
            }
            ftl_mgr::Event::Finished => {
                state.toplevels.clear();
                state.recompute_hidden();
            }
            _ => {}
        }
    }

    event_created_child!(State, ZwlrForeignToplevelManagerV1, [
        ftl_mgr::EVT_TOPLEVEL_OPCODE => (ZwlrForeignToplevelHandleV1, ()),
    ]);
}

impl Dispatch<ZwlrForeignToplevelHandleV1, ()> for State {
    fn event(
        state: &mut Self,
        handle: &ZwlrForeignToplevelHandleV1,
        event: ftl_handle::Event,
        _: &(),
        _conn: &Connection,
        _qh: &QueueHandle<Self>,
    ) {
        let id = handle.id();
        match event {
            ftl_handle::Event::State { state: arr } => {
                let (fullscreen, activated) = parse_toplevel_state(&arr);
                if let Some(t) = state.toplevels.get_mut(&id) {
                    t.fullscreen = fullscreen;
                    t.activated = activated;
                }
                state.recompute_hidden();
            }
            ftl_handle::Event::Closed => {
                state.toplevels.remove(&id);
                state.recompute_hidden();
            }
            _ => {}
        }
    }
}

// ── Camino COSMIC / GNOME ───────────────────────────────────────────────────
// `ext-foreign-toplevel-list-v1` da la lista de ventanas; por cada una se pide
// a `zcosmic_toplevel_info_v1` (v2) un `zcosmic_toplevel_handle_v1` cuyo evento
// `state` trae los mismos flags (`activated`, `fullscreen`) que el protocolo wlr.

impl Dispatch<ExtForeignToplevelListV1, ()> for State {
    fn event(
        state: &mut Self,
        _list: &ExtForeignToplevelListV1,
        event: ext_list::Event,
        _: &(),
        _conn: &Connection,
        qh: &QueueHandle<Self>,
    ) {
        match event {
            ext_list::Event::Toplevel { toplevel } => {
                // Puente v2: obtener el handle COSMIC para poder leer el estado.
                let Some(info) = state.cosmic_info.as_ref() else {
                    return;
                };
                let cosmic = info.get_cosmic_toplevel(&toplevel, qh, ());
                state.toplevels.insert(cosmic.id(), TopInfo::default());
                state
                    .ext_to_cosmic
                    .insert(toplevel.id(), (toplevel, cosmic));
            }
            ext_list::Event::Finished => {
                state.toplevels.clear();
                state.ext_to_cosmic.clear();
                state.recompute_hidden();
            }
            _ => {}
        }
    }

    event_created_child!(State, ExtForeignToplevelListV1, [
        ext_list::EVT_TOPLEVEL_OPCODE => (ExtForeignToplevelHandleV1, ()),
    ]);
}

impl Dispatch<ExtForeignToplevelHandleV1, ()> for State {
    fn event(
        state: &mut Self,
        handle: &ExtForeignToplevelHandleV1,
        event: ext_handle::Event,
        _: &(),
        _conn: &Connection,
        _qh: &QueueHandle<Self>,
    ) {
        // El handle COSMIC v2 no emite `closed` propio: el de la lista es el
        // equivalente, así que aquí se limpian los dos.
        if let ext_handle::Event::Closed = event {
            if let Some((ext_h, cosmic_h)) = state.ext_to_cosmic.remove(&handle.id()) {
                state.toplevels.remove(&cosmic_h.id());
                cosmic_h.destroy();
                ext_h.destroy();
                state.recompute_hidden();
            }
        }
    }
}

impl Dispatch<ZcosmicToplevelInfoV1, ()> for State {
    fn event(
        state: &mut Self,
        _info: &ZcosmicToplevelInfoV1,
        event: cosmic_info::Event,
        _: &(),
        _conn: &Connection,
        _qh: &QueueHandle<Self>,
    ) {
        if let cosmic_info::Event::Finished = event {
            state.toplevels.clear();
            state.ext_to_cosmic.clear();
            state.recompute_hidden();
        }
        // `done`: agrupa cambios de forma atómica; no lo necesitamos.
    }
}

impl Dispatch<ZcosmicToplevelHandleV1, ()> for State {
    fn event(
        state: &mut Self,
        handle: &ZcosmicToplevelHandleV1,
        event: cosmic_handle::Event,
        _: &(),
        _conn: &Connection,
        _qh: &QueueHandle<Self>,
    ) {
        if let cosmic_handle::Event::State { state: arr } = event {
            let (fullscreen, activated) = parse_toplevel_state(&arr);
            if let Some(t) = state.toplevels.get_mut(&handle.id()) {
                t.fullscreen = fullscreen;
                t.activated = activated;
            }
            state.recompute_hidden();
        }
    }
}

/// Guarda un búfer BGRA premultiplicado como un fichero PNG con transparencia recta (RGBA).
fn save_frame_as_png(
    bgra: &[u8],
    w: u32,
    h: u32,
    path: &std::path::Path,
) -> Result<(), Box<dyn Error>> {
    let mut rgba = vec![0u8; (w * h * 4) as usize];
    for (src, dst) in bgra.chunks_exact(4).zip(rgba.chunks_exact_mut(4)) {
        let a = src[3];
        if a == 0 {
            dst[0] = 0;
            dst[1] = 0;
            dst[2] = 0;
            dst[3] = 0;
        } else {
            let a_u32 = a as u32;
            dst[0] = ((src[2] as u32 * 255) / a_u32).min(255) as u8; // R
            dst[1] = ((src[1] as u32 * 255) / a_u32).min(255) as u8; // G
            dst[2] = ((src[0] as u32 * 255) / a_u32).min(255) as u8; // B
            dst[3] = a;
        }
    }
    let file = std::fs::File::create(path)?;
    let mut w_buf = std::io::BufWriter::new(file);
    let mut enc = png::Encoder::new(&mut w_buf, w, h);
    enc.set_color(png::ColorType::Rgba);
    enc.set_depth(png::BitDepth::Eight);
    let mut writer = enc.write_header()?;
    writer.write_image_data(&rgba)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn next_wake_at_toma_el_candidato_mas_cercano() {
        let now = Instant::now();
        let cap = Duration::from_millis(200);
        let near = now + Duration::from_millis(30);
        let far = now + Duration::from_millis(500);
        assert_eq!(
            next_wake_at(now, &[Some(far), Some(near), None], cap),
            near,
            "el más próximo, ignorando `None`"
        );
    }

    #[test]
    fn next_wake_at_ignora_candidatos_pasados() {
        let now = Instant::now();
        let cap = Duration::from_millis(200);
        let pasado = now - Duration::from_millis(5);
        let futuro = now + Duration::from_millis(80);
        assert_eq!(
            next_wake_at(now, &[Some(pasado), Some(futuro)], cap),
            futuro,
            "un candidato ya vencido no cuenta (se ignora, no dispara sondeo inmediato en bucle)"
        );
    }

    #[test]
    fn next_wake_at_sin_candidatos_cae_al_tope_de_reposo() {
        let now = Instant::now();
        let cap = Duration::from_millis(200);
        assert_eq!(next_wake_at(now, &[None, None, None], cap), now + cap);
    }

    #[test]
    fn next_wake_at_no_acorta_un_candidato_mas_lejano_que_el_tope() {
        // Un sprite sheet lento (p. ej. 1 fps) no debe despertarse antes de lo
        // que le toca solo porque el tope de reposo sea más corto.
        let now = Instant::now();
        let cap = Duration::from_millis(200);
        let lejos = now + Duration::from_secs(1);
        assert_eq!(next_wake_at(now, &[Some(lejos)], cap), lejos);
    }
}
